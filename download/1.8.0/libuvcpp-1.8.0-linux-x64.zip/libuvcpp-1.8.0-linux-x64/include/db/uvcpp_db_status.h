﻿/**
 * @file src/db/uvcpp_db_status.h
 * @brief 数据库模块的返回码。
 * @author zhuweiye
 * @version 1.0.0
 *
 * 本模块**不抛异常**（与库内其余模块一致）：所有可能失败的操作返回
 * `uvcpp_db_status`，失败原因另有一份人读的文本，从 `uvcpp_db_client::last_error()`
 * 取。两个理由：
 *
 *  1. 失败在数据库这条路上是**常态**（唯一键冲突、连接被中间件掐断、SQL 写错），
 *     不是异常情形。用返回码，调用方在写代码时就得处理它。
 *  2. `catch` 跨动态库边界在 Windows 上是另一套 ABI 规则，预编译包里必然踩。
 *
 * 返回码只区分「哪一类失败」，不试图枚举数据库自己的错误号 —— 那属于各家驱动
 * 的私有词汇表。要 SQLSTATE / errno 时看 `last_error()` 里的原文。
 */

#pragma once
#ifndef SRC_DB_UVCPP_DB_STATUS_H
#define SRC_DB_UVCPP_DB_STATUS_H

#include <uvcpp/uvcpp_config.h>
#include <uvcpp/uvcpp_export.h>

#if UVCPP_DB_ENABLE

#include <cstddef>

namespace uvcpp {

enum class uvcpp_db_status : int {
  /// 成功。
  OK = 0,

  /// 连接串解析不了（缺 scheme、缺 '@'、端口不是数字……）。
  BAD_URL,

  /// 这个 scheme 的后端**在这一份构建里用不了**。与 BAD_URL 分开，是因为
  /// 前者是调用方写错了，后者是发行方式的选择 —— 预编译包少了哪个后端，
  /// 使用者应该在这里一眼看见，而不是拿到一句「打不开连接」。
  ///
  /// 有**两条**路会走到这里，而 `last_error()` 会把是哪一条说清楚：
  ///
  ///   * 后端**根本没编进这个库**（`UVCPP_ENABLE_DB_MYSQL` 之类的宏是 0）。
  ///     这时 `uvcpp_db_driver_available("mysql")` 也是 false —— 看一眼就知道，
  ///     不用去读错误串。
  ///   * 后端**编进来了**，但 `UVCPP_DB_RUNTIME_LOAD` 那份构建是**运行时**才
  ///     去 `dlopen` 客户端库的，而这台机器上没装（或装在一个找不到的前缀下）。
  ///     这时 `uvcpp_db_driver_available()` 仍是 **true**（它说的是"这个后端
  ///     在不在库里"，那是编译期的事实），错误串里会列出**试过哪几个库名**、
  ///     并给出两条出路：装一个客户端库，或者用 `UVCPP_DB_MYSQL_LIBRARY` /
  ///     `UVCPP_DB_PGSQL_LIBRARY` 显式指路。
  ///
  /// 第二种情况**不是进程级的**：它只影响真的去连那个后端的这一条连接，
  /// 同一进程里的 SQLite、HTTP 服务等一切照常 —— 这也是运行时加载相对
  /// 直接链（`DT_NEEDED` 是**加载期**解析，缺库连进程都起不来）的唯一理由。
  NO_DRIVER,

  /// 打开连接失败：主机/端口不可达、认证失败、库不存在、超时。
  OPEN_FAILED,

  /// 连接没打开就调了需要连接的操作，或执行途中连接掉了且重连也没成功。
  NOT_CONNECTED,

  /// 语句准备失败：SQL 语法错、表/列不存在。（PostgreSQL 的裸通道也会把
  /// 「没有这个表」报在这里。）
  PREPARE_FAILED,

  /// 语句执行失败：约束冲突、类型不匹配、死锁重试用尽、权限不足。
  EXEC_FAILED,

  /// 参数与占位符对不上（个数、或名字找不到）。
  BIND_FAILED,

  /// 这个后端不支持该操作（例如 SQLite 没有存储过程、没有 `lastval()`）。
  UNSUPPORTED,

  /// 用法错误：空 SQL、空结果集指针、未 open 就 query。
  MISUSE,

  /// 内存不足。
  OUT_OF_MEMORY,

  /// **连接池借不出连接**：池子已到上限且都在外借，等到 `acquire` 超时也没等到。
  /// 与 `NOT_CONNECTED` 分开，是因为后者说的是「这条连接没打开」—— 拿它顶这一条
  /// 就是撒谎：池子里每条连接都是好的，只是**没有空闲的**。而这两件事的处置办法
  /// 完全不同：前者该重连，后者该扩容（或把借出的还回来）。
  ///
  /// 只有 `uvcpp_db_pool` 会产生它。
  NO_CONNECTION,
};

/// 返回码的稳定短名（英文、小写下划线），用于日志与测试断言。
/// 稳定意味着：可以写进测试的期望值，改名算破坏性变更。
UVCPP_API const char* uvcpp_db_status_name(uvcpp_db_status status);

/// 是否成功。写成函数而不是宏，是为了让 `if (uvcpp_db_ok(st))` 有类型。
inline bool uvcpp_db_ok(uvcpp_db_status status) {
  return status == uvcpp_db_status::OK;
}

}  // namespace uvcpp

#endif  // UVCPP_DB_ENABLE
#endif  // SRC_DB_UVCPP_DB_STATUS_H
