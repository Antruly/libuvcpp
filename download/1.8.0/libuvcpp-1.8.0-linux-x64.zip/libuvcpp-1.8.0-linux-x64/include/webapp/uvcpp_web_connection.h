﻿/**
 * @file src/webapp/uvcpp_web_connection.h
 * @brief 连接的身份与登记表：把「裸 client 指针」换成「永不复用的 id」。
 * @author zhuweiye
 * @version 1.0.0
 *
 * 为什么要有这一层
 * ----------------
 * 异步 handler 的基本形态是「把活交给线程池，回调里再写响应」。写响应需要
 * 连接，而连接是个 `uvcpp_tcp_client*` —— **那个指针在异步期间可能已经失效**：
 * 对端断开，服务端把它 delete 掉，地址随后被一条新连接复用。这时回调拿着
 * 旧指针去写，数据就写到了别人的连接上。这不是理论风险：现有的
 * `uvcpp_static_server` 异步读盘那条路径就是裸指针，注释里也承认了。
 *
 * 判空挡不住它 —— 指针非空，只是指向了另一个对象。**换成 id 才挡得住**：
 *
 * @code
 *   uvcpp_web_conn_id id = registry.add(client, ip, port);   // 1, 2, 3... 绝不重复
 *   // ... 异步 ...
 *   uvcpp_tcp_client* c = registry.client(id);   // 断开过 → nullptr
 *   if (c == nullptr) { drop_response_and_log(); return; }
 * @endcode
 *
 * id 是单调递增且**永不复用**的，所以「连接 7 已经死了」这个事实不会因为
 * 新连接拿到 7 而变成谎话。登记表内部的 `by_client_` 反向索引则保证同一个
 * client 只会有一条记录。
 *
 * 线程约束
 * --------
 * 登记表**只能在 loop 线程上操作**（accept / close 都发生在那里）。异步
 * 回调要从别的线程查，得先 `context::post()` 回到 loop 线程。
 */

#pragma once
#ifndef SRC_WEBAPP_UVCPP_WEB_CONNECTION_H
#define SRC_WEBAPP_UVCPP_WEB_CONNECTION_H

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <unordered_map>
#include <string>
#include <vector>

#include <uvcpp/uvcpp_define.h>
#include <uvcpp/uvcpp_export.h>

namespace uvcpp {

class uvcpp_loop;
class uvcpp_tcp_client;

/**
 * @brief 一条连接的身份。
 *
 * 从 1 开始（0 是无效值），单调递增，**永不复用**。
 */
typedef uint64_t uvcpp_web_conn_id;

/** @brief 无效 / 未知的连接 id。 */
const uvcpp_web_conn_id UVCPP_WEB_INVALID_CONN_ID = 0;

/**
 * @brief 连接 id 的位布局：**高 20 位是循环号，低 44 位是该登记表自己的递增号**。
 *
 * 多循环之前 id 就是那份递增号本身，也就是"高段恒 0"。所以**单循环下的取值
 * 逐字节不变**（`id == seq`，从 1 开始），下面这两个常量只在循环号非 0 时才
 * 参与运算。
 *
 * 为什么必须编码：`issued()` 的判据原是 `id < next_id_`（"比下一个要发的号小
 * ⇒ 曾经发过"），而把登记表切成 per-loop 的 n 份之后，**每份都有自己的
 * `next_id_`** ⇒ 那条判据会对**别的循环发出去的号**返回真。加上"高段与我相同"
 * 之后，`issued()`/`alive()`/`find()` 都只认自己的号，而且"这个 id 归哪条循环"
 * 是一次位运算，不需要全 app 搜索。
 *
 * 20 位循环号 = 每进程最多 1 048 576 条循环（远超任何真实配置）；44 位递增号
 * = 每条循环 1.7×10^13 条连接，"永不复用"的语义因此不受影响。
 */
const int UVCPP_WEB_CONN_LOOP_SHIFT = 44;
/** @brief 取递增号那一段的掩码（`UVCPP_WEB_CONN_LOOP_SHIFT` 位全 1）。 */
const uvcpp_web_conn_id UVCPP_WEB_CONN_SEQ_MASK = (1ULL << 44) - 1;

/**
 * @brief 登记表里的一条连接记录。
 *
 * 只在 `uvcpp_web_connection_registry` 存活期内有效，且 `client` 只在
 * `alive` 为真时可用。
 */
struct UVCPP_API uvcpp_web_connection {
  uvcpp_web_conn_id id;
  /** @brief 底层连接。**登记表从不解引用它**，只当作身份用。 */
  uvcpp_tcp_client* client;
  std::string       peer_ip;
  int               peer_port;

  /**
   * @brief 最近一次**收到字节**的时刻（毫秒，`uv_now` 基准）。
   *
   * `0` 表示还不知道 —— 登记时没给时间戳就会这样。扫描器第一次看到这种
   * 连接时会补一个基准，而不是当成"从时间原点起就没动过"直接杀掉（那会让
   * 每一条刚建立的连接都活不过第一拍）。
   */
  int64_t last_read_ms;

  /**
   * @brief 当前这个「半截请求」的第一个字节到达的时刻；`0` = 当前没有半截请求。
   *
   * 为什么要有它：只用 `last_read_ms` 挡不住慢速攻击 —— 攻击者每 30 秒发一个
   * 字节，空闲计时就永远是新鲜的。改成「**整个请求**的预算」之后，无论中间
   * 发不发字节，这个请求都必须在超时之内收完。
   *
   * 由 `note_read()` 在这条连接上"没有半截请求"时置上，由
   * `note_request_done()` 清零（响应发出、请求结束）。
   */
  int64_t request_start_ms;

  /**
   * @brief 这条连接当前是不是**流式收体中**（body 正在按块交付给 handler）。
   *
   * 它改变的是「活动基准取哪一个」这一件事，但**必须存在**，因为两种计时方式
   * 对流式请求都不成立：
   *
   * - 沿用 `request_start_ms`（整段预算）→ 一个 2 GB 的上传即使一直在推进，
   *   也会在上限那一刻被当成慢速攻击杀掉；
   * - 不豁免（按 `last_read_ms`）→ 这正是要的，但 `idle_sweep` 对在途请求
   *   是**整体豁免**的，于是流式上传变成永远不超时。
   *
   * 所以流式期间的语义是「**停顿保护**」：只要还在收字节就不动它，停止推进超过
   * `idle_timeout_ms` 就关。由框架在认领时置真、在消息结束/中止时清掉；
   * `note_request_done()` 也会清（它是"这个请求结束了"的唯一收口）。
   */
  bool streaming;

  /// 显式构造函数，**不用 NSDMI**（那会破坏 C++11 的聚合初始化）。
  uvcpp_web_connection();
};

/**
 * @brief 一次 splitmix64 finalizer：把键的**低位结构**打散。
 *
 * 为什么必须显式混洗，而不是直接用 `std::hash`：
 * `std::unordered_map` 的桶数在两个平台上不一样 —— libstdc++ 用**素数**桶，
 * MSVC 用**2 的幂**桶（桶号 = hash & (桶数-1)）。在后者上，恒等的 hash 意味着
 * 「桶号 = 键的低位」，而本表的两把钥匙恰好都是低位有结构的：
 *
 * - `uvcpp_web_conn_id` 是 `next_id_++` 发出来的**顺序号**；
 * - `uvcpp_tcp_client*` 来自同一尺寸的分配，**同类对象常落在各页的同一偏移上**。
 *
 * 低位同余 ⇒ 全挤进少数几个桶 ⇒ 查表退化成链走查，而这**在 Linux 上量不出来**
 * （那边的素数桶把它遮住了）。所以这里不赌平台：先混一道再交给容器。代价约
 * 5 个周期，而一次查表省下的是 9 层指针追逐。
 *
 * 这条不是推测：`t1/n3/reg_cmp.cpp` 拿 1000 个同尺寸节点、按 **MSVC 的桶策略**
 * 重算过 —— 低位族只用 64 个桶、最长桶 16；混洗族用 635 个桶、最长桶 4。
 * （复现的是**机理**；它在 MSVC 上的**发生频率**本装置没量。）
 */
inline uint64_t uvcpp_web_conn_mix64(uint64_t x) {
  x ^= x >> 33;
  x *= 0xff51afd7ed558ccdULL;
  x ^= x >> 33;
  x *= 0xc4ceb9fe1a85ec53ULL;
  x ^= x >> 33;
  return x;
}

/** @brief `uvcpp_web_conn_id` 的散列（理由见 @ref uvcpp_web_conn_mix64）。 */
struct uvcpp_web_conn_id_hash {
  size_t operator()(uvcpp_web_conn_id id) const {
    return static_cast<size_t>(uvcpp_web_conn_mix64(id));
  }
};

/** @brief `uvcpp_tcp_client*` 的散列（理由见 @ref uvcpp_web_conn_mix64）。 */
struct uvcpp_web_conn_ptr_hash {
  size_t operator()(const uvcpp_tcp_client* p) const {
    return static_cast<size_t>(uvcpp_web_conn_mix64(
        static_cast<uint64_t>(reinterpret_cast<uintptr_t>(p))));
  }
};

/**
 * @brief 连接登记表：id ↔ 活连接的映射。
 *
 * @warning 只在 loop 线程上用。内部的 `std::unordered_map` 不是线程安全的。
 */
class UVCPP_API uvcpp_web_connection_registry {
 public:
  /**
   * @param loop_index 这份登记表归哪条循环管（多循环时用来给 id 打高段）。
   *                   **单循环用默认值 0**，此时发出去的 id 与多循环之前逐字节
   *                   相同（就是 1、2、3…）。越界（<0 或 ≥2^20）时按 0 处理。
   */
  explicit uvcpp_web_connection_registry(int loop_index = 0);
  ~uvcpp_web_connection_registry();

  UVCPP_DEFINE_COPY_FUNC_DELETE(uvcpp_web_connection_registry)

  /** @brief 这份登记表管的循环号（构造时给的）。 */
  int loop_index() const { return loop_index_; }

  /**
   * @brief 从任意 id 里取循环号 —— **不需要这份 id 属于哪份登记表**。
   *
   * 这就是"按 id 找循环"的那一次位运算：跨循环的调用方（比如"这个 id 该由
   * 谁处理"）先用它定位，再去找那份登记表。
   */
  static int loop_of(uvcpp_web_conn_id id) {
    return static_cast<int>(id >> UVCPP_WEB_CONN_LOOP_SHIFT);
  }

  /** @brief 从任意 id 里取递增号那一段（不含循环号）。 */
  static uvcpp_web_conn_id seq_of(uvcpp_web_conn_id id) {
    return id & UVCPP_WEB_CONN_SEQ_MASK;
  }

  /** @brief 把 `(循环号, 递增号)` 拼回一个 id。`loop_of`/`seq_of` 的逆运算。 */
  static uvcpp_web_conn_id make_id(int loop_index, uvcpp_web_conn_id seq) {
    return (static_cast<uvcpp_web_conn_id>(loop_index) << UVCPP_WEB_CONN_LOOP_SHIFT) |
           (seq & UVCPP_WEB_CONN_SEQ_MASK);
  }

  /**
   * @brief 登记一条新连接，返回它的 id。
   *
   * 同一个 `client` 重复登记是**调用方的 bug**，这里不会静默吞掉：旧记录会
   * 被先摘掉（否则 `by_client_` 会指着一条失效记录），再建新的。id 因此可能
   * 出现「同一个 client 有两个 id，只有后一个有效」的情况 —— 这正是重复登记
   * 该有的表现。
   *
   * @return 新分配的 id，永不为 `UVCPP_WEB_INVALID_CONN_ID`。
   */
  uvcpp_web_conn_id add(uvcpp_tcp_client* client,
                        const std::string& peer_ip = std::string(),
                        int peer_port = 0,
                        int64_t now_ms = 0);

  // -----------------------------------------------------------------
  // 活动时间（闲置超时的依据）
  // -----------------------------------------------------------------

  /**
   * @brief 记一次「收到字节」。
   *
   * 顺便把「半截请求」的起点定下来：**如果当前没有半截请求，这次收到的字节
   * 就是新请求的第一个字节**，于是 `request_start_ms` 置为 @p now_ms。
   * 登记表不认识 HTTP 分帧，但「上一个请求答完之后的第一块字节」正好就是
   * 新请求的开头 —— 而 `note_request_done()` 已经把上一个请求清零了。
   *
   * @param now_ms `uv_now` 基准的毫秒时刻。
   * @return 记录存在并已更新。
   */
  bool note_read(uvcpp_web_conn_id id, int64_t now_ms);

  /**
   * @brief 记一次「这个请求已经答完」，`request_start_ms` 归零。
   *
   * 下一次 `note_read()` 收到的字节就属于新请求，拿一个全新的预算。
   * keep-alive 连接的第二个请求因此能重新计时。
   */
  bool note_request_done(uvcpp_web_conn_id id);

  /**
   * @brief 标记/清除这条连接的「流式收体中」状态。
   *
   * 置真之后 `activity_since()` 改用 `last_read_ms`，于是超时从「整个请求的
   * 预算」变成「**停顿**多久没进展」。`note_request_done()` 会无条件清掉，
   * 所以即使调用方漏了清，它也不会漏到下一个请求上去。
   *
   * @return 记录存在。
   */
  bool mark_streaming(uvcpp_web_conn_id id, bool streaming);

  /** @brief 这条连接是否处于「流式收体中」。记录不存在时为 false。 */
  bool is_streaming(uvcpp_web_conn_id id) const;

  /**
   * @brief 这条连接的**活动基准时刻** —— 闲置超时该从哪一刻算起。
   *
   * - 正在流式收体 → `last_read_ms`（只要还在收字节就不算超时，停下来才超时）；
   * - 正在收一个半截请求 → `request_start_ms`（按整个请求的预算算，慢速
   *   滴字节拖不过去）；
   * - 否则 → `last_read_ms`（连接之间的空闲按最后一次收字节算）。
   *
   * @return `uv_now` 基准的毫秒时刻；记录不存在、或者还没有基准时为 `0`。
   */
  int64_t activity_since(uvcpp_web_conn_id id) const;

  /**
   * @brief 给一条还不知道活动时刻的连接补基准。
   *
   * **只在 `last_read_ms` 为 0 时写**，所以可以每拍都无脑调。存在的意义
   * 是「登记时没给时间戳」（默认参数 0）的那些记录：第一次扫描时补一个
   * 基准，让它从这一刻开始算，而不是被当成上古连接当场杀掉。
   *
   * @return 记录存在。
   */
  bool touch(uvcpp_web_conn_id id, int64_t now_ms);

  /** @brief 摘掉一条记录。@return 记录存在并已摘除。 */
  bool remove(uvcpp_web_conn_id id);

  /**
   * @brief 按 client 指针摘除（对端断开时只知道指针，不知道 id）。
   *
   * @param[out] out_id 若非空，收到被摘除的 id（供日志用）。
   * @return 找到并摘除了记录。
   */
  bool remove_by_client(uvcpp_tcp_client* client,
                        uvcpp_web_conn_id* out_id = nullptr);

  /**
   * @brief id → 活连接。
   *
   * @return 连接**当前活着**时返回它的指针；已经断开、或者这个 id 压根没
   *         发出过，都返回 `nullptr`。
   *
   * **不要把这个指针存到异步回调里** —— 那正是本文件要解决的问题。要用
   * 就在 loop 线程上现查现用。
   */
  uvcpp_tcp_client* client(uvcpp_web_conn_id id) const;

  /**
   * @brief client 指针 → id（`client()` 的反向查询）。
   *
   * 给 HTTP 层的入口用：请求到达时手上只有 `uvcpp_tcp_client*`（那是 HTTP
   * 服务器给的），而框架想用 id 记账。查不到返回 0 —— 0 永远不是有效的
   * 连接 id（id 从 1 开始发）。
   */
  uvcpp_web_conn_id id_of(uvcpp_tcp_client* client) const;

  /** @brief 这条连接现在是否还活着。 */
  bool alive(uvcpp_web_conn_id id) const;

  /**
   * @brief 这个 id 是不是**本登记表**曾经发出去的（不管现在是不是还活着）。
   *
   * 用来区分两种 `client() == nullptr`：「连接已经断了」（正常，记一条
   * debug 就够了）和「这个 id 根本不存在」（框架自己的 bug，要报 error）。
   * 靠递增号单调实现，不需要额外存一张"死 id 表"。
   *
   * **两个条件缺一不可**：递增号比本表的下一个号小，**并且**循环号就是本表的
   * 循环号。少了后一条，切分登记表之后这条判据会对**别的循环**发的号返回真
   * —— 而那些号在本表里一个都查不到，`client()`/`find()` 会同时给出"曾经发过"
   * 和"查不到任何记录"这对矛盾答案，调用方只能二选一地误判。
   */
  bool issued(uvcpp_web_conn_id id) const;

  /** @brief 取一条记录的副本。不存在返回 nullptr。 */
  const uvcpp_web_connection* find(uvcpp_web_conn_id id) const;

  /**
   * @brief 当前活连接数。
   *
   * **这是本表唯一的跨线程读数口**：它读的是一个原子量，不是 `by_id_.size()`。
   * 多循环下 `connection_count()` 要把各格加起来，而"加起来"这件事会在别的
   * 线程正在改那张 `std::map` 的时候发生 —— 遍历它是数据竞争，读原子不是。
   *
   * 这是本仓**唯一**允许从非循环线程读的成员，其余一概不行（见类头的
   * `@warning`）。
   */
  size_t size() const;

  /** @brief 当前所有活连接的 id（顺序按 id 升序）。 */
  std::vector<uvcpp_web_conn_id> ids() const;

  /**
   * @brief 本登记表历史上分配过的 id 总数（含已断开的）。
   *
   * **是每份登记表各自的计数，不是全进程的**：多循环下 app 级的"累计连接数"
   * 要把各循环的读数加起来（各 `loop_index` 统一后不重复计数）。
   */
  uint64_t issued_count() const;

  /** @brief 清空登记表。**已经发出去的 id 不会被回收**，下一个 id 接着涨。 */
  void clear();

 private:
  /**
   * @brief id → 记录。
   *
   * `std::unordered_map` 而不是 `std::map`：这是**每请求至少三次**的热查表
   * （`find` / `note_read` / `note_request_done`），而两把钥匙的低位都有结构
   * ⇒ 见 `uvcpp_web_conn_mix64` 里"为什么必须显式混洗"。
   *
   * **节点稳定**这一条不能丢：`find()` 把记录指针交给调用方（`uvcpp_web_app`
   * 拿它读 `peer_ip`/`peer_port`），而 `unordered_map` 只在 rehash 时重建桶
   * 数组，元素本身不搬 —— 与 `std::map` 一样。
   */
  typedef std::unordered_map<uvcpp_web_conn_id, uvcpp_web_connection,
                             uvcpp_web_conn_id_hash> by_id_map;
  typedef std::unordered_map<uvcpp_tcp_client*, uvcpp_web_conn_id,
                             uvcpp_web_conn_ptr_hash> by_client_map;
  by_id_map     by_id_;
  by_client_map by_client_;
  /**
   * @brief 下一个要发的**递增号**（不含循环号的那一段）。
   *
   * 从 1 开始：0 要留给 `UVCPP_WEB_INVALID_CONN_ID`，不然"没登记过"和"第 0 条
   * 连接"就分不开了。它**永不复位**（`clear()` 也不动它），"永不复用"全靠这一条。
   */
  uvcpp_web_conn_id next_id_;
  /** @brief 本登记表的循环号，组装 id 时放进高段。 */
  int loop_index_;

  /**
   * @brief `by_id_.size()` 的镜像，**只在四个改动函数末尾按 size 赋值**。
   *
   * 为什么不写成 `++` / `--`：`add()` 开头那次"重复登记先摘旧的"会让一次
   * `add` 同时产生一次减和一次加，`remove()` 里也有"反向索引指着的不是我"
   * 那种不加不减的分支 —— 按 `size()` 赋值是把"最终该是多少"交给唯一知道
   * 答案的那张表，而不是让每一个分支各自记着该加还是该减。
   *
   * 也正因为"按 size 赋值"，它**只在循环线程上被写**（那四个函数都只从本
   * 循环的回调里进），读它的人可以在任何线程上 —— 这正是它存在的理由。
   */
  mutable std::atomic<size_t> live_;
};

}  // namespace uvcpp

#endif  // SRC_WEBAPP_UVCPP_WEB_CONNECTION_H
