﻿/**
 * @file src/webapp/uvcpp_web_static.h
 * @brief 框架原生的静态文件服务：Range/断点续传、ETag/304、LRU 缓存、安全边界。
 * @author zhuweiye
 * @version 1.0.0
 *
 * 与 `src/web/uvcpp_static_server.{h,cpp}` 的关系
 * ----------------------------------------------
 * 那个是协议层的旧实现，本模块**不基于它**，也不打算替换它（它还有自己的
 * 使用者）。两者解决的是同一件事，但旧实现有几个结构性缺陷，本模块从设计上
 * 就不存在：
 *
 * | 旧实现 | 本模块 |
 * |---|---|
 * | 异步读盘回调持有裸 `uvcpp_tcp_client*`，地址被新连接复用就会把 A 的响应发给 B | 框架按 **连接 id** 取活连接，取不到就丢弃响应 —— 身份不是指针，"复用"这个问题不存在 |
 * | 同步 `uv_fs_stat` 在循环线程上 | 全部走 `uvcpp_work`，循环线程只做组包 |
 * | 挂载前缀 `/static` 与 `/static/` 取不到 index | 前缀与 `前缀/*path` 两条路由都注册，等价处理 |
 * | HEAD 返回 body | HEAD 与 GET 走**同一条路**（一样读盘、一样进缓存），装好 body 后由 `set_head_only(true)` 在序列化时丢掉 —— 因为 `Content-Length` 与 `Content-Encoding` 都是 HTTP 层压缩决策的结果，不给真 body 就算不出 GET 会发的长度 |
 *
 * 异步与线程模型
 * --------------
 * 每次请求**只投一次 `uvcpp_work`**，worker 线程里把「解析候选 → stat →
 * （必要时）读盘」一口气做完，用的都是标准文件 IO，**不碰任何 libuv 对象**
 * —— 这是刻意的：`uvcpp_fs` 的 `uv_fs_t` 是对象级共享的，同一个对象上不能
 * 有两个在途操作，在"每请求一次 IO"的场景里用它，要么每请求 new 一个对象，
 * 要么就得小心翼翼串行化，两条路都比直接用标准 IO 更绕。
 *
 * 读盘结果是 `std::shared_ptr<std::string>`，完成回调（跑在 loop 线程上）里
 * **按值**捕获这个 shared_ptr，所以请求上下文的生存期与它无关 —— 连接断了、
 * 请求被丢弃，数据也只是正常析构。
 *
 * 缓存
 * ----
 * LRU，同时受「条目数」和「总字节数」两个上限约束（只限条目数的话，256 个
 * 大文件就能把内存吃光）。
 *
 * **缓存是共享一份的，不是每循环一份**，因此内部有一把锁（多循环下
 * `serve()` 与完成回调会跑在**不同的循环线程**上）。之所以不分片：分片会让
 * 每片各攒一份 LRU，内存成倍、命中率还掉 —— 同一条路径的请求落到不同片上
 * 就互相看不见。单循环下这把锁没有可争用的对象。实现见
 * `uvcpp_web_static.cpp` 里 `Impl::mu_` 的注释。
 *
 * 校验方式是把缓存条目的 `(mtime, size)` 作为"期望值"快照带进 work job：
 * worker stat 之后先比这个快照 —— 对上了就**不读盘**，直接告诉调用方"用你
 * 手里那份"；对不上才真读。所以热文件是**一次 stat、零次读盘**。
 *
 * 这次 stat 跑在哪里由 `uvcpp_web_revalidate` 定，**默认 `POOL`**（进线程池，
 * 命中也要过一次池子）：换来的是"校验一定发生在文件系统上"、而且不会挡住同一条
 * 循环上的其它连接。`LOOP_STAT` 把 stat 搬到**循环线程**上同步做 —— 省掉每请求
 * 一次提交 + 唤醒 + `after_work` 三次跨线程往返（命中路径实测掉的正是这一段），
 * 代价是一个会挡住同循环的阻塞 stat：本地盘微秒级，FUSE/网络盘上十几到几十微秒
 * 起（46 µs 那个读数就是 FUSE），所以只适合已知盘型的部署显式开。
 * **两种档的语义逐字相同**：下一个请求仍然一定看到磁盘上现在的字节。
 *
 * 安全边界
 * --------
 * 两道，缺一不可：
 *   1. `web_sanitize_path()` —— 纯文本归一化，挡掉所有编码绕过
 *      （`%2e%2e%2f`、`..\\`、`C:`、NUL……）；
 *   2. `web_resolve_within_root()` —— 展开符号链接后做**真实路径**的包含
 *      判断，挡住"根目录里有个指向 C:\\Windows 的链接"。
 *
 * 只有第 1 道是**不够的**：纯文本层面 `/link/system32/x` 完全合法。
 *
 * 路径解析记忆（第 2 道的摊销，选项 `resolve_memo`）
 * -------------------------------------------------
 * 第 2 道是**每请求一次 `realpath`**，而 `realpath` 要沿路径逐分量 `lstat`。
 * 实测（20 个 URL 的混载、ext4、static-h2 形状、20 000 请求的窗口）它占每请求
 * **2.73 次** `realpath` 调用 —— 这是本模块热路径上最大的一笔文件系统开销。
 *
 * 于是把上一次的解析结论记下来：`fs_path`（展开后的绝对路径）加上
 * `(st_dev, st_ino)`。worker 命中时只做一次 `stat` 比对指纹，不再 `realpath`；
 * `statx` 次数与不记忆时**逐条相同**（慢路径本来也要 `stat` 一次拿 mtime/size），
 * 所以这一步是纯赚。
 *
 * 为什么这是安全的，而不是"拿路径文本当结论"：`stat` 与 `realpath` 走的是
 * **同一条 VFS 解析**。`(dev, ino)` 没变 ⟺ 还是那个文件 ⟺ 当初"它在根内"那个
 * 判断仍然是**对这个文件**的判断。路径被换向时（`/hintdir` 从真目录换成指向
 * 根外的链接）`stat` 会跟着新链接落到另一个 inode 上 ⇒ 指纹对不上 ⇒ 落回完整
 * 解析、然后拒绝。`test_resolve_hint` 测的就是这一步：把指纹比对去掉（改成只信
 * 路径文本）之后它必须变红，而且红在**内容**上（根外那个文件的字节真的发出去了），
 * 不是红在状态码上。
 *
 * **已知且接受的一处行为差异**：路径的落点被整体搬到根外、原位留下一个指向
 * **同一个 inode** 的链接时（`mv` 到根外 + `ln -s` 回原位），指纹不变 ⇒ 命中
 * 路径继续按原 URL 服务它，而完整解析会判越界。差别是"曾经被授权过的那份字节
 * 多活一会儿"，不是读到没被授权过的字节；`rm` 立即生效，`validate.sh` 的
 * staleness 探针用 `mv -f` 换文件（inode 必变）也不受影响。要绝对严格就关掉
 * `resolve_memo`（一行）。
 *
 * 大文件与流式下发
 * ----------------
 * **小文件**（≤ `max_cached_file_size`，默认 1 MiB）走原路：worker 整读进
 * 内存 + LRU + `resp.body(...)` 一份拷贝。**大文件**改走
 * `uvcpp_web_file_transfer` 的分片异步读（`resp.send_file_range()`），
 * 每片交给 sink 之后就不再持有，峰值与文件大小**无关**。
 *
 * 这样做之前，任何大小的文件都是整读，于是峰值是 **2N** —— 而 LRU 的字节
 * 上限（32 MiB）意味着大文件本来也进不了缓存，整读对它没换来任何收益。
 *
 * 分片读要的是"能一片一片读出来"的载体，不是 `uv_fs_sendfile` ——
 * 后者在 Windows 上是 CRT fd 上的用户态 `_read`/`_write` 循环（写不到 libuv
 * 的连接上），在 Unix 上要求 `out_fd` 是**裸 socket fd**（TLS 过滤后的
 * `uvcpp_tcp_client` 不暴露它，且开 SSL 时字节必须走 `SSL_write`）。所以那
 * 条零拷贝路径在两个平台上都用不了，详见 `uvcpp_web_file.h` 的文件头。
 *
 * `max_file_size`（默认 64 MiB）仍然是**独立的**一道闸门：它管的是"最大的
 * 那个文件有多大"，超限回 413 且一个字节都不读；阈值管的是"从哪个大小开始
 * 不整读"。两者的判据不同，不要合并。
 */

#pragma once
#ifndef SRC_WEBAPP_UVCPP_WEB_STATIC_H
#define SRC_WEBAPP_UVCPP_WEB_STATIC_H

#include <cstddef>
#include <deque>
#include <list>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include <uvcpp/uvcpp_define.h>
#include <uvcpp/uvcpp_export.h>
#include <webapp/uvcpp_web_handler.h>
#include <webapp/uvcpp_web_mime.h>
#include <webapp/uvcpp_web_work_limit.h>

namespace uvcpp {

class uvcpp_web_app;
class uvcpp_web_request;
class uvcpp_web_response;
class uvcpp_loop;

// =========================================================================
// 选项
// =========================================================================

/**
 * @brief 以 `.` 开头的路径段（`.git`、`.env`）怎么处理。
 *
 * @note 第一个枚举量叫 `HIDE` 而不是 `IGNORE`：`IGNORE` 是 Windows 头文件
 *       （`winnt.h`）里的宏，`#define IGNORE 0`，写出来会被预处理成 `0 = 0`
 *       这种语法错误 —— 而且报错位置在枚举上，看着和 Windows 毫无关系。
 *       枚举类的作用域**挡不住**宏。
 */
enum class uvcpp_web_dotfile_policy : int {
  /**
   * 当作不存在（404）。**默认**。
   *
   * 404 而不是 403 是刻意的：403 等于确认"这个文件存在，只是不给你"，
   * 对 `.env`、`.git/config` 这类探测来说，那就已经泄漏了信息。
   */
  HIDE = 0,
  /** 明确拒绝（403）。想让运维一眼看出"有人在扫"时用。 */
  DENY,
  /** 照常提供。只在文档根只放公开内容、且确实需要 `.well-known` 之类时用。 */
  ALLOW,
};

/**
 * @brief 缓存校验（"缓存里那份还算不算数"）在哪条线程上做。
 *
 * 两档的**语义完全相同** —— 都是"下一次请求一定拿磁盘上现在的字节"，区别只在
 * 校验那次 `stat` 跑在哪条线程上：
 *
 * | 档 | 校验在哪 | 缓存命中的代价 |
 * |---|---|---|
 * | `POOL` | 线程池 worker | 每请求一次池往返（`uv_queue_work` + 唤醒 + `after_work`） |
 * | `LOOP_STAT` | 请求所在的那条循环线程 | 一次同步 `stat`，**一个池任务都不投** |
 *
 * `LOOP_STAT` 之所以成立：校验只需要一次 `stat`，而 `stat` 在本地文件系统上
 * 是微秒级的（ext4 实测 1.35 µs）。把它放进池子换来的是每请求两次跨线程唤醒
 * （提交一次、回来一次）—— 实测在 8 核打满时，`uvcpp_web_static` 的每请求
 * CPU 里有约 12~19 µs 花在 `futex`/`pthread_cond_signal`/`__lll_lock_*` 上，
 * 而那一段**全部**来自这次池往返。命中时省掉它，等于把那 12~19 µs 直接抹掉。
 *
 * @note 代价与适用面（**所以默认是 `POOL`**）：`LOOP_STAT` 把一次阻塞 `stat`
 *       放在循环线程上，同一条循环上的其它连接要等它。本地盘（ext4/xfs/
 *       btrfs、tmpfs）上这个等待是微秒级；FUSE、网络盘（NFS/SMB）上是几十
 *       微秒到毫秒级 —— 实测同一个 `stat` 在 FUSE 挂载上是 46 µs（ext4 的
 *       34 倍），那时该等的是**别的连接**，该留在池子里。用之前先量一下自己的
 *       文档根所在文件系统。
 */
enum class uvcpp_web_revalidate : int {
  /** 校验在线程池 worker 里做。**默认**，也是 1.6.24 之前唯一的行为。 */
  POOL = 0,
  /** 校验在循环线程上直接 `stat`。本地盘上的高吞吐场景。 */
  LOOP_STAT,
};

/** @brief `.well-known` 这类目录即使策略是 `HIDE` 也应当放行的白名单。 */
struct UVCPP_API uvcpp_web_static_options {
  /** @brief 目录请求时按顺序尝试的索引文件名。默认 `{"index.html"}`。 */
  std::vector<std::string> index_files;

  /**
   * @brief 找不到文件时是否回落到单页应用入口（默认 false）。
   *
   * 开了之后 `/user/42` 这种前端路由会拿到 `spa_file`（默认 `index.html`）
   * 而不是 404。**注意它只对"路径不存在"生效**：路径存在但被安全策略拒绝
   * （穿越、dotfile）时仍然按拒绝处理 —— 否则 SPA 回落会把一次探测变成一个
   * 200，安全问题就再也看不见了。
   */
  bool spa_fallback;
  std::string spa_file;

  /**
   * @brief 单个文件的大小上限，超过回 413 且**不读盘**。默认 64 MiB。
   *
   * 这是"读进内存"这个实现的必要配套：没有它，一个 2 GiB 的文件请求就能
   * 把进程内存打爆。0 = 不限（**别这么用**，除非你确定文档根里都是小文件）。
   */
  size_t max_file_size;

  /** @brief 是否发 `ETag` 并处理 `If-None-Match`。默认 true。 */
  bool etag;
  /** @brief 是否发 `Last-Modified` 并处理 `If-Modified-Since`。默认 true。 */
  bool last_modified;
  /**
   * @brief 是否支持 `Range`（断点续传 / 拖动进度条）。默认 true。
   *
   * 关掉之后不回 `Accept-Ranges`，`Range` 头被忽略（回 200 全量）。
   */
  bool range;

  /**
   * @brief `Cache-Control` 的值。空 = 不发这个头。
   *
   * 带指纹的静态资源建议 `"public, max-age=31536000, immutable"`；
   * HTML 入口建议 `"no-cache"`。**框架不替你猜** —— 它不知道哪个文件带指纹。
   */
  std::string cache_control;

  /** @brief 缓存条目数上限。0 = 关掉缓存。默认 256。 */
  size_t cache_max_entries;
  /** @brief 缓存总字节上限。0 = 不按字节限制。默认 32 MiB。 */
  size_t cache_max_bytes;

  /**
   * @brief 分流阈值：文件**大于**它就走分片读下发（`send_file_range`），
   *        不再整读进内存。默认 1 MiB。
   *
   * 两条路径的峰值内存差得很远，这是本选项存在的全部理由：
   *
   * | 大小 | 路径 | 峰值 |
   * |---|---|---|
   * | ≤ 阈值 | worker 整读 + LRU + `resp.body(...)` 一份拷贝 | ≤ 2 × 阈值 |
   * | > 阈值 | 分片异步读 + 有界滑动窗口 | ≈ 切片 + 高水位 ≈ 1.5 MiB |
   *
   * 阈值不是随手取的：LRU 的字节上限默认 32 MiB，所以**大文件今天本来就
   * 进不了缓存**（`put()` 会把上限撑爆）。也就是说整读那条路对大文件**没
   * 换来任何缓存收益**，只换来 2N 的峰值 —— 而小资源（热 CSS/JS/图标）才
   * 是缓存真正划算的地方，它们的第二份拷贝正好被阈值卡住。
   *
   * **0 = 一律走流式**（"没有文件小到值得缓存"），与 `cache_max_entries = 0`
   * （关掉缓存）是同一种读法。注意这跟本仓多数 setter 的"0 = 用默认值"
   * **相反** —— 阈值没有"未配置"这个状态，不配就是 1 MiB。
   *
   * **超过阈值不只是"缓存够不着"，是整条路都不压。** 大文件走
   * `send_file_range()` → `begin_stream()`，那条入口压根不调用
   * `apply_compression()`，所以它既没有 `content-encoding` 也没有 `vary` ——
   * 与"客户端根本没发 `Accept-Encoding`"**逐字节相同**。想让大文件也压，
   * 得改成流式 deflate（每块一个上下文），那是另一个特性。
   *
   * 真要做，**先考虑的不是流式 deflate**：构建期压好同名兄弟文件（`x.js.gz`，
   * nginx `gzip_static` 那种形状）把流式要付的三项成本一次绕开 —— 块边界不
   * 存在（整份文件）、`content-length` 已知（兄弟文件的大小）、与
   * `transfer-encoding` 没有交互。它换不来"任意大文件"（得先压好），但静态
   * 资源的可压缩主体（js / css / wasm / json）本来就是打包器产出的，那一步
   * 天然已经做过（**1.6.15 已经做了，即下面的 `precompressed`**）。代价是
   * 那条路**自己**得声明 `vary: accept-encoding` —— 它
   * 同样不经过 `apply_compression()`，拿不到那处声明，上面"逐字节相同"这句
   * 届时也就不再成立。
   *
   * 所以本选项实际的含义是"**从哪个大小起不压缩**"。调大它买到的是"这个
   * 尺寸以下的资源走整读 + 变体缓存"，**买不到**大文件的压缩率：调多大都
   * 不会让 2 MiB 的那个文件变小。
   */
  size_t max_cached_file_size;

  /**
   * @brief 是否使用**预压缩孪生文件**（`app.js.br` / `app.js.gz`）。默认 false。
   *
   * 开了之后，盘上有孪生文件的资源直接读它、原样发出去（带上
   * `content-encoding` 与 `vary: accept-encoding`），**不再走实时压缩**。形状与
   * nginx 的 `gzip_static`、Caddy 的 `precompressed br gzip` 一致，也正是上面
   * `max_cached_file_size` 里"先考虑的不是流式 deflate"那段说的那条路。
   *
   * 选择规则：`br` 的 `q` 不低于 `gzip` 时取 `.br`（同 `q` 时 brotli 更小），
   * 否则取 `.gz`；**首选那份不在盘上就试下一个** —— 于是客户端两份都接受而只有
   * `.gz` 存在时会退到它（nginx 双模块、Caddy 都是这个次序）。客户端一个都没
   * 声明就照旧发原文件。`q=0` 是**明确拒绝**（RFC 9110 §12.5.3），不会因为
   * "只声明了它"而被选中。孪生文件**不存在**时退回原文件，于是"没预压过的
   * 资源"与关掉本选项时逐字节相同。
   *
   * 三条边界，都是为了不把"压缩"和"内容协商"搅在一起：
   *  - **带 `Range` 的请求一律不用孪生文件** —— 要切的是**原文件**的字节，
   *    对孪生文件切段会切出一段没有意义的压缩流。与实时压缩那条"206 一律
   *    不编码"是同一条规则。
   *  - **阈值量的是孪生文件自己**：孪生文件 ≤ `max_cached_file_size` 才用它，
   *    原文件多大不参与这个判定 —— 于是 2 MiB 的原文件照样能靠一个 1 KB 的边车
   *    下发（分片下发那条路不经过响应层，挂不上 `content-encoding`，所以孪生文件
   *    **自己**超阈值时不能走它）。
   *  - **不套用 MIME 排除表**：排除表管的是"要不要**实时**压"，而 `.br` 已经
   *    在盘上了。也正因为如此，`image/svg+xml` 这类默认被排除的类型，只要盘上
   *    有孪生文件就会用上。
   *
   * 孪生文件自己的 `mtime`/大小参与全部缓存判定（`ETag`、`Last-Modified`、
   * LRU 的失效比较都取它），所以重新压一遍之后对端必然拿到新的那一份。
   */
  bool precompressed;

  /**
   * @brief 缓存校验（`stat`）跑在哪条线程上。默认 `POOL`。
   *
   * 见 `uvcpp_web_revalidate` 的表格与那段 @note —— **`POOL` 是 1.6.24 之前
   * 唯一的行为，逐字节等价**；`LOOP_STAT` 只在文档根位于本地文件系统时开。
   */
  uvcpp_web_revalidate revalidate;

  /**
   * @brief 是否复用上一次的**路径解析**结论。默认 `true`。
   *
   * 解析一次 URL 要一次 `realpath`，而 `realpath` 要沿路径逐分量 `lstat`；
   * 开本选项后，命中缓存的路径只做一次 `stat` 比对 `(st_dev, st_ino)`，
   * 不再 `realpath`。**系统调用数不变**（慢路径本来也要 `stat` 一次拿
   * mtime/size），省下的是那一整条 `realpath`。完整的安全论证与"已知的一处
   * 行为差异"写在 `uvcpp_web_static.h` 文件头的「路径解析记忆」一节。
   *
   * 关掉它 = 逐字节回到不做记忆时的行为（每个请求一次 `realpath`）。
   * 差异**只在一种情形**下可见：某个路径的落点被整体搬到文档根之外、而
   * 原地留下一个指向**同一个 inode** 的链接 —— 那时记忆里的结论仍然成立
   * （还是那个文件），完整解析则会判它越界。`tests/functional/
   * web_app_static_func.cpp` 的 `test_resolve_hint` 覆盖了换向那一步。
   */
  bool resolve_memo;

  /** @brief dotfile 策略。默认 `HIDE`（404）。 */
  uvcpp_web_dotfile_policy dotfiles;

  /**
   * @brief 是否允许通过符号链接提供文件。默认 true。
   *
   * @warning 关掉它**只检查最后一段**：`root/a.link/file.txt` 里 `a.link`
   *          是指向根外的链接时，挡住它的是
   *          `web_resolve_within_root()` 的包含判断（无论本选项如何），
   *          而不是本选项。本选项管的是"目标文件本身就是个链接"。
   */
  bool follow_symlinks;

  /** @brief 文本类型是否追加 `; charset=utf-8`。默认 true。 */
  bool add_charset;

  /**
   * @brief 自定义 MIME 表。nullptr = 用 `uvcpp_web_mime_map::default_map()`。
   *
   * **不持有所有权**，调用方必须保证它活得比本选项久（通常是个静态量或
   * App 的成员）。
   */
  const uvcpp_web_mime_map* mime;

  /** @brief 显式构造函数（不用 NSDMI —— 那会破坏 C++11 聚合初始化）。 */
  explicit uvcpp_web_static_options(size_t max_file = 64u * 1024u * 1024u);
};

// =========================================================================
// 静态服务
// =========================================================================

/**
 * @brief 静态文件服务。
 *
 * 通常不直接构造，而是走 `uvcpp_web_app::serve_static()` —— 它负责建对象、
 * 注册路由、并把 `shared_ptr` 交回给你（想手动清缓存时要用）。
 *
 * 生命周期：对象被路由里的 handler **按值捕获 shared_ptr** 持有，所以只要
 * App 活着它就活着，不需要额外管理。
 */
class UVCPP_API uvcpp_web_static {
 public:
  /**
   * @param root_dir 文档根。构造时就做一次 `web_real_path()` 归一化并缓存
   *                 （每请求再算一遍是纯浪费），之后**不再回头看配置**。
   *                 解析失败（目录不存在）时不会抛异常，而是让之后每个请求
   *                 都回 500 —— 这是部署错误，用 500 让它立刻可见，
   *                 比静默 404 却发现不了要强。
   */
  uvcpp_web_static(const std::string& root_dir,
                   const uvcpp_web_static_options& opts);
  ~uvcpp_web_static();

  UVCPP_DEFINE_COPY_FUNC_DELETE(uvcpp_web_static)

  const uvcpp_web_static_options& options() const;

  /**
   * @brief 构造函数解析并缓存的**真实**文档根。
   *
   * 空串 = 配置错误（构造时 `web_real_path()` 失败，已打过 `ERROR`）。拿它做
   * "别的目录是不是落在本根里"这类判断 —— 典型是 `uvcpp_web_app` 拒绝把上传
   * 目录设在文档根里。**返回的是构造时那一次解析的结果，不是重新解析**：
   * 调用方本就需要一个稳定基准，再算一遍既浪费又可能因为目录被换掉而不一致。
   */
  const std::string& root_real() const;

  /**
   * @brief 清空 LRU 缓存（例如部署了新版本之后）。
   *
   * 可以从**任何线程**调：它与服务路径共享的那几个成员都在 `Impl::mu_` 里
   * （从前这里写着"只能在 loop 线程调"，那是"缓存没有锁"年代的约束）。
   */
  void clear_cache();

  /** @brief 缓存条目数/占用字节数。跨线程可读（走 `Impl::mu_`）。 */
  size_t cache_entries() const;
  size_t cache_bytes() const;

  /** @brief 缓存命中/未命中计数，便于确认缓存真的在工作。跨线程可读。 */
  unsigned long long cache_hits() const;
  unsigned long long cache_misses() const;

  /**
   * @brief 服务一个请求。**框架内部接口**，使用者请用
   *        `uvcpp_web_app::serve_static()`。
   *
   * @param loop 投递读盘任务用的循环，**必须是请求所在的那个循环**。
   *             多循环下它还是**待回收 `uvcpp_work` 的桶键**（每条循环只删
   *             自己投出去的那些）—— 传错不会崩，但会把回收时机拖到析构。
   *
   * 为什么要显式传 loop：handler 的签名是 `(req, resp, next)`，里面既没有
   * 上下文也没有 App，**拿不到循环**。而循环要到 `start()` 之后才存在，
   * 注册期（handler 被创建时）也拿不到 —— 所以只能在每次请求时由调用方
   * （也就是 App）从自己身上取。
   *
   * 路径从 `req.param("path")` 取通配段；没有该参数时按空路径处理
   * （挂载前缀本身 → 走索引文件）。
   */
  void serve(uvcpp_web_request& req, uvcpp_web_response& resp,
             uvcpp_web_next next, uvcpp_loop* loop);

  /**
   * @brief 装上工作池在途上限。
   *
   * 装上之后，worker 在**真正要读盘的那一步之前**先要一个名额。拿不到名额时
   * **按走哪一支分两种**（`1.3.6-dev` 起）：
   *
   * - **整读进内存那一支**（文件 ≤ `max_cached_file_size`）：回
   *   **503 + `Retry-After`**。取与还**都在 `run_job()` 里**（读之前拿、读完
   *   立刻还）—— 还名额这一步是 `1.6.42-dev` 从 `after_work()` 搬过来的，
   *   理由与下面分片那一支逐条相同。
   * - **超过阈值走分片那一支**：**不拒**，改由传输自己**按块借还**
   *   （`uvcpp_web_file_transfer::set_chunk_gate()`）—— 读一块之前拿、读完
   *   立刻还，拿不到就停在块边界上等唤醒。于是名额封的是"真正并行的读盘数"，
   *   并发再高也只是**慢**，不是失败。
   *
   * **为什么持到 `after_work` 是错的**（分片那一支 2026-09-24 改的，整读这
   * 一支 `1.6.42-dev` 跟上）：`after_work` 跑在**循环线程**上，循环线程一忙
   * 它就排不上队，名额于是被"一个字节都还没读"（分片，改前）或"一个字节都
   * 读完了、只是在等循环线程"（整读，改前）的请求攥着 —— 服务端自己那行日志
   * 就是现场：`工作池已满（在途 0 / 16），拒绝静态请求 /big.bin`（**在途 0 却
   * 拒绝**），以及整读路上的 `工作池已满（在途 256 / 256）`。实测：分片支用
   * `ab -c 1000` 打 8 MiB 文件、4000 个请求，503 从 **267 → 0**、rps **73 →
   * 161**（同一批、同一台机）；整读支用 1024 连接 × `-m 32` 打 20 个静态
   * 文件，503 从 **3,642 → 0**。
   *
   * 取名额的位置是 `run_job()` 里那条读盘语句之前，**不是**投递任务之前 ——
   * "要不要读盘"只有 stat 完才知道（命中缓存、404 都不用读），在投递前判会
   * 把那些请求一起 503 掉。整读那一支 503 的产出位置是 `finish_job()` 里的
   * 一个 `REJECTED` 分支（细节见 `uvcpp_web_static.cpp`）。
   *
   * 为什么**整读**那一支只能拒绝、不能背压：走到那里时请求**已经整包读完**了
   * （静态路由是普通路由，body 早收完），字节不在网上，没有"让对端慢点发"
   * 这种退路 —— 它没有"停在块边界"这种形状，因为它是**一次**读完的。分片支
   * 相反，它本来就分块，而那条续做通道是为背压建的，顺带就能承载名额等待。
   * 上传路径同理 —— 那里字节还在读，所以它的分工是 `stream->pause()`，见
   * `uvcpp_web_work_limit` 的说明。
   *
   * @param limit 共享持有（App 传自己的那个）；**传空 = 不限**，也就是本类
   *              原本的行为。直接构造 `uvcpp_web_static` 的使用者不调它，
   *              行为与从前完全一致。
   */
  void set_work_limit(const std::shared_ptr<uvcpp_web_work_limit>& limit);

  /** @brief 当前装着的上限对象；没装时为**空**。 */
  std::shared_ptr<uvcpp_web_work_limit> work_limit() const;

  /** @brief 因为工作池满而被回绝（503）的请求数。 */
  unsigned long long rejected_count() const;

 private:
  struct Impl;
  Impl* impl_;
};

}  // namespace uvcpp

#endif  // SRC_WEBAPP_UVCPP_WEB_STATIC_H
