﻿/**
 * @file src/req/uvcpp_write.h
 * @brief Wrapper for uv_write_t to perform asynchronous stream writes.
 * @author zhuweiye
 * @version 1.0.0
 */

#pragma once
#ifndef SRC_REQ_UVCPP_WRITE_H
#define SRC_REQ_UVCPP_WRITE_H

#include <req/uvcpp_req.h>
#include <uvcpp/uvcpp_buf.h>

namespace uvcpp {
/**
 * @brief Write request wrapper for stream write operations.
 *
 * Use `set_buf` / `set_src_buf` to configure buffers. Provide `m_write_cb`
 * to receive completion notifications.
 */
class UVCPP_API uvcpp_write : public uvcpp_req {
 public:
  UVCPP_DEFINE_FUNC(uvcpp_write)
  UVCPP_DEFINE_COPY_FUNC_DELETE(uvcpp_write)

  /** @brief Initialize the write request. */
  int init();

  /** @brief Set the main buffer to write; if owner=true wrapper will free it. */
  void set_uv_buf(uv_buf_t *bf, bool owner = false);
  /** @brief Get the buffer previously set. */
  uv_buf_t *get_uv_buf();

  // -----------------------------------------------------------------
  // 第二块（头/体分开写，`uv_write` 的 `nbufs = 2`）
  // -----------------------------------------------------------------
  //
  // 为什么要两块：一条 HTTP 响应天然是**两段**（头部块 + 体），把两段先合并成
  // 一条再交下来，合并那一步就得把体整份拷一遍。`uv_write` 本来就收**数组**，
  // 所以"分开交"不需要协议层做任何事 —— 需要的是有人**保证第二块活到完成
  // 回调**，因为 libuv 的契约是"缓冲在回调之前一直有效"，它不会替你拷一份。
  //
  // 上面两个方法就是这份保证的两种形状：那块字节要么是**别人的**（靠引用计数
  // 借来用），要么是**本请求接管下来的**（自己释放）。两者与 `set_uv_buf` 的
  // 差别都在所有权，不在字节。

  /**
   * @brief 追加第二块：一份**共享视图**。
   *
   * @param bf   第二块的字节范围（通常是共享串的整段）。
   * @param hold 让这块存活的那个引用。本请求把它持到析构，于是 `uv_write`
   *             那句"缓冲要活到回调"由引用计数履行。`hold` 为空仍是合法的
   *             （等价于本请求不负责第二块的存活，调用方自己保证）。
   *
   * 必须在 `set_uv_buf` **之后**调用（第 1 块是在这一刻被快照进数组的）。
   *
   * 第 2 块**只有一个**：再调一次（两种入口混着调也算）会把上一个占用者换掉，
   * 旧的按它自己的所有权放掉（owned 的释放、view 的放引用）。
   */
  void append_uv_buf_view(uv_buf_t bf,
                          const ::std::shared_ptr<const ::std::string> &hold);

  /**
   * @brief 追加第二块：一块**自有**的块，所有权转移给本请求。
   *
   * @param bf 必须来自 `uvcpp_buf::out_uv_buf()`（它把块**连同所有权**交出来）；
   *           本请求析构时按 `uvcpp_buf::free_buf` + `uvcpp_free` 放掉。
   *           注意释放用的是**这个原指针**，所以调用方不要先给 `bf->base`
   *           加偏移再传进来（`free_buf` 释放的正是 `bf->base`）。
   *
   * 第 2 块**只有一个**：再调一次会把上一个占用者换掉（见 `append_uv_buf_view`）。
   * 同一个 `bf` 交两次不会双释放，但那是调用方的错 —— 所有权只能交一次。
   */
  void append_uv_buf_owned(uv_buf_t *bf);

  /**
   * @brief 第 1 块的**值形态**：块归本请求，但不经过堆上的 `uv_buf_t`。
   *
   * @param bf 必须来自 `uvcpp_buf::release_uv_buf()`（它把块连同所有权填进一个
   *           调用方给的 `uv_buf_t`，且**不分配包装**）。本请求析构时放掉
   *           `bf.base`。
   *
   * 与 `set_uv_buf()` 的差别只在包装：那个收的是 `uvcpp_alloc` 出来的指针，
   * 释放要 `free_buf` + `uvcpp_free` 两步；这个收的是值，释放只有放块这一步。
   * 两种形态**择一使用**（后设的会把先设的按它自己的归属放掉）。
   */
  void set_uv_buf_block(uv_buf_t bf);

  /**
   * @brief 第 2 块的**值形态**：块归本请求，同样不经过包装。
   *
   * @param bf 同 `set_uv_buf_block`，必须来自 `uvcpp_buf::release_uv_buf()`。
   *           第 2 块同样只有一个槽位，换占用者按 `append_uv_buf_owned` 的规矩来。
   */
  void append_uv_buf_block(uv_buf_t bf);

  /**
   * @brief 复用前的复位：放掉上一笔的字节（自有块 / 共享视图引用），第 1 块也
   *        清成空 —— 下一笔自己会重设。**保留**自己的 `uv_write_t`。
   *
   * 给"按连接复用同一个写请求对象"那条路用（见
   * `uvcpp_tcp_client::write_owned`）：请求对象申请一次、每笔响应重用，于是
   * `uv_write_t` 与请求对象这两笔堆分配从"每请求"降到**每连接**。
   *
   * 只动"上一笔的字节归谁"：`hold_` / `second_owner` / `second_block_base_`
   * 全部按各自的归属放掉。漏一个的后果不是泄漏而是"第二块是上一笔的"——
   * 复用时下一次 append 会把占用者换掉，而那个槽位里还留着上一笔的块或视图。
   */
  void reset_for_reuse();

  /**
   * @brief 第 2 块：接手 `body`（`is_shared()` ⇒ 接引用计数；否则 ⇒ 接块的所有权）。
   *
   * 与 `uvcpp_tcp_client::write(head, head_len, body, cb)` 的体处理是**同一份**
   * 判据，顺序也不能反（`release_uv_buf()` 会先把共享视图 materialize 成一份
   * 拷贝，共享视图走错那一支就白拷一次）。抽到这里是为了不让第二个调用点各抄
   * 一份 —— 本仓的 ws 那族就是这么来的（见 `start_write` 那条同族注释）。
   */
  void adopt_body(uvcpp_buf* body);

  /**
   * @brief 本次写要交给 `uv_write` 的缓冲数组。
   *
   * 只有 1 块时返回 `get_uv_buf()`（与既有形状逐字一致）；有 2 块时返回内部
   * 那个连续数组。libuv 会在 `uv_write` 里把 `uv_buf_t` 数组自身拷走，但**不拷
   * 数据** —— 数据要活到回调，这正是上面两个 append 存在的理由。
   */
  uv_buf_t *get_uv_bufs();
  /** @brief 本次写的块数（1 或 2）。 */
  size_t get_uv_nbufs() const;
  /** @brief Set a source buffer (used for send_handle scenarios). */
  void set_src_buf(const uvcpp_buf *bf, bool owner = false);
  /** @brief Get the source buffer previously set. */
  const uvcpp_buf *get_src_buf();
  ::std::function<void(uvcpp_write*,int)> m_write_cb;
 public:

  /** @brief libuv uv_write_cb forwarded to m_write_cb. */
  static void callback_write(uv_write_t *req, int status);

  private:
  uv_buf_t *uv_buf = nullptr;
  const uvcpp_buf *src_buf = nullptr;
  bool uv_buf_owner = false;
  bool src_buf_owner = false;

  // 第 1 块仍由 uv_buf 持有（它可能是 out_uv_buf() 交出来的，也可能是空块），
  // 所以两块要交给 uv_write 时先把第 1 块**快照**进这个连续数组 —— `uv_write`
  // 收的是 `const uv_buf_t bufs[]`，两块必须连续。数组本身只要活到 `uv_write`
  // 返回（libuv 会把 uv_buf_t 数组拷进请求里），但**数据**要活到完成回调。
  size_t nbufs_ = 1;
  uv_buf_t pair_[2];
  // 第 2 块只有一个槽位，两种占用形状共用它；换占用者（含析构）一律走这里，
  // 否则被覆盖掉的那个再也没人放。
  void release_second();

  // 第 2 块若是自有块，这里记着它的**原始**头：释放必须用原指针（free_buf 释放
  // 的是 base），所以接收方不许先把 base 加偏移再传进来。
  uv_buf_t *second_owner = nullptr;

  // ---- 值形态（set_uv_buf_block / append_uv_buf_block）----
  //
  // 块按值存在这里，`uv_buf` 指向第 1 块的槽（于是 `pair_[]` 快照、`get_uv_bufs`
  // 这些既有逻辑一个字都不用改）。要释放的**只有块**，所以另记 base：`uv_buf`
  // 指向的是成员，`uvcpp_free` 它就是在 free 栈上/成员地址。
  uv_buf_t first_block_;
  void *first_block_base_ = nullptr;
  uv_buf_t second_block_;
  void *second_block_base_ = nullptr;

  // 第 2 块若是共享视图，靠它活着 —— 见 append_uv_buf_view。
  ::std::shared_ptr<const ::std::string> hold_;
};
} // namespace uvcpp

#endif // SRC_REQ_UVCPP_WRITE_H