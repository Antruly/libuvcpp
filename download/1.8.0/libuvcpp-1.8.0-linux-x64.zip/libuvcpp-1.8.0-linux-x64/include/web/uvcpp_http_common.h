﻿/**
 * @file src/web/uvcpp_http_common.h
 * @brief HTTP common types: methods, status codes, versions, headers.
 * @author zhuweiye
 * @version 1.0.0
 *
 * Defines the fundamental HTTP types used throughout the web module.
 * The http_method values match llhttp's internal numbering so that the
 * uvcpp_http_parser can map directly without translation.
 *
 * uvcpp_http_version pre-defines HTTP_2_0 as a placeholder for future implementation.
 */

#pragma once
#ifndef SRC_WEB_UVCPP_HTTP_COMMON_H
#define SRC_WEB_UVCPP_HTTP_COMMON_H

#include <uvcpp/uvcpp_config.h>

#if UVCPP_WEB_ENABLE

#include <cstdint>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

namespace uvcpp {

// =========================================================================
// HTTP 方法 — 值与 llhttp 内部编号一致，便于直接映射
// =========================================================================

enum class http_method : uint8_t {
  HTTP_DELETE      = 0,
  HTTP_GET         = 1,
  HTTP_HEAD        = 2,
  HTTP_POST        = 3,
  HTTP_PUT         = 4,
  HTTP_CONNECT     = 5,
  HTTP_OPTIONS     = 6,
  HTTP_TRACE       = 7,
  HTTP_COPY        = 8,
  HTTP_LOCK        = 9,
  HTTP_MKCOL       = 10,
  HTTP_MOVE        = 11,
  HTTP_PROPFIND    = 12,
  HTTP_PROPPATCH   = 13,
  HTTP_SEARCH      = 14,
  HTTP_UNLOCK      = 15,
  HTTP_BIND        = 16,
  HTTP_REBIND      = 17,
  HTTP_UNBIND      = 18,
  HTTP_ACL         = 19,
  HTTP_REPORT      = 20,
  HTTP_MKACTIVITY  = 21,
  HTTP_CHECKOUT    = 22,
  HTTP_MERGE       = 23,
  HTTP_MSEARCH     = 24,
  HTTP_NOTIFY      = 25,
  HTTP_SUBSCRIBE   = 26,
  HTTP_UNSUBSCRIBE = 27,
  HTTP_PATCH       = 28,
  HTTP_PURGE       = 29,
  HTTP_MKCALENDAR  = 30,
  HTTP_LINK        = 31,
  HTTP_UNLINK      = 32,
  HTTP_SOURCE      = 33,
  HTTP_PRI         = 34,  ///< HTTP/2 Priority (reserved for future use)
};

/** @brief Convert http_method to its standard string representation. */
inline const char* http_method_str(http_method m) {
  switch (m) {
    case http_method::HTTP_DELETE:      return "DELETE";
    case http_method::HTTP_GET:         return "GET";
    case http_method::HTTP_HEAD:        return "HEAD";
    case http_method::HTTP_POST:        return "POST";
    case http_method::HTTP_PUT:         return "PUT";
    case http_method::HTTP_CONNECT:     return "CONNECT";
    case http_method::HTTP_OPTIONS:     return "OPTIONS";
    case http_method::HTTP_TRACE:       return "TRACE";
    case http_method::HTTP_COPY:        return "COPY";
    case http_method::HTTP_LOCK:        return "LOCK";
    case http_method::HTTP_MKCOL:       return "MKCOL";
    case http_method::HTTP_MOVE:        return "MOVE";
    case http_method::HTTP_PROPFIND:    return "PROPFIND";
    case http_method::HTTP_PROPPATCH:   return "PROPPATCH";
    case http_method::HTTP_SEARCH:      return "SEARCH";
    case http_method::HTTP_UNLOCK:      return "UNLOCK";
    case http_method::HTTP_BIND:        return "BIND";
    case http_method::HTTP_REBIND:      return "REBIND";
    case http_method::HTTP_UNBIND:      return "UNBIND";
    case http_method::HTTP_ACL:         return "ACL";
    case http_method::HTTP_REPORT:      return "REPORT";
    case http_method::HTTP_MKACTIVITY:  return "MKACTIVITY";
    case http_method::HTTP_CHECKOUT:    return "CHECKOUT";
    case http_method::HTTP_MERGE:       return "MERGE";
    case http_method::HTTP_MSEARCH:     return "MSEARCH";
    case http_method::HTTP_NOTIFY:      return "NOTIFY";
    case http_method::HTTP_SUBSCRIBE:   return "SUBSCRIBE";
    case http_method::HTTP_UNSUBSCRIBE: return "UNSUBSCRIBE";
    case http_method::HTTP_PATCH:       return "PATCH";
    case http_method::HTTP_PURGE:       return "PURGE";
    case http_method::HTTP_MKCALENDAR:  return "MKCALENDAR";
    case http_method::HTTP_LINK:        return "LINK";
    case http_method::HTTP_UNLINK:      return "UNLINK";
    case http_method::HTTP_SOURCE:      return "SOURCE";
    case http_method::HTTP_PRI:         return "PRI";
    default:                            return "UNKNOWN";
  }
}

// =========================================================================
// HTTP 状态码 — RFC 7231 等规范定义的常用状态码
// =========================================================================

enum class http_status : int {
  // 1xx Informational
  CONTINUE                        = 100,
  SWITCHING_PROTOCOLS             = 101,
  PROCESSING                      = 102,
  EARLY_HINTS                     = 103,

  // 2xx Success
  OK                              = 200,
  CREATED                         = 201,
  ACCEPTED                        = 202,
  NON_AUTHORITATIVE_INFORMATION   = 203,
  NO_CONTENT                      = 204,
  RESET_CONTENT                   = 205,
  PARTIAL_CONTENT                 = 206,

  // 3xx Redirection
  MULTIPLE_CHOICES                = 300,
  MOVED_PERMANENTLY               = 301,
  FOUND                           = 302,
  SEE_OTHER                       = 303,
  NOT_MODIFIED                    = 304,
  USE_PROXY                       = 305,
  TEMPORARY_REDIRECT              = 307,
  PERMANENT_REDIRECT              = 308,

  // 4xx Client Error
  BAD_REQUEST                     = 400,
  UNAUTHORIZED                    = 401,
  PAYMENT_REQUIRED                = 402,
  FORBIDDEN                       = 403,
  NOT_FOUND                       = 404,
  METHOD_NOT_ALLOWED              = 405,
  NOT_ACCEPTABLE                  = 406,
  PROXY_AUTHENTICATION_REQUIRED   = 407,
  REQUEST_TIMEOUT                 = 408,
  CONFLICT                        = 409,
  GONE                            = 410,
  LENGTH_REQUIRED                 = 411,
  PRECONDITION_FAILED             = 412,
  PAYLOAD_TOO_LARGE               = 413,
  URI_TOO_LONG                    = 414,
  UNSUPPORTED_MEDIA_TYPE          = 415,
  RANGE_NOT_SATISFIABLE           = 416,
  EXPECTATION_FAILED              = 417,
  IM_A_TEAPOT                     = 418,
  MISDIRECTED_REQUEST             = 421,
  UNPROCESSABLE_ENTITY            = 422,
  UPGRADE_REQUIRED                = 426,
  TOO_MANY_REQUESTS               = 429,
  REQUEST_HEADER_FIELDS_TOO_LARGE = 431,

  // 5xx Server Error
  INTERNAL_SERVER_ERROR           = 500,
  NOT_IMPLEMENTED                 = 501,
  BAD_GATEWAY                     = 502,
  SERVICE_UNAVAILABLE             = 503,
  GATEWAY_TIMEOUT                 = 504,
  HTTP_VERSION_NOT_SUPPORTED      = 505,
};

/** @brief Return the standard reason phrase for an HTTP status code. */
inline const char* http_status_reason(http_status s) {
  switch (s) {
    case http_status::CONTINUE:                        return "Continue";
    case http_status::SWITCHING_PROTOCOLS:             return "Switching Protocols";
    case http_status::PROCESSING:                      return "Processing";
    case http_status::EARLY_HINTS:                     return "Early Hints";
    case http_status::OK:                              return "OK";
    case http_status::CREATED:                         return "Created";
    case http_status::ACCEPTED:                        return "Accepted";
    case http_status::NON_AUTHORITATIVE_INFORMATION:   return "Non-Authoritative Information";
    case http_status::NO_CONTENT:                      return "No Content";
    case http_status::RESET_CONTENT:                   return "Reset Content";
    case http_status::PARTIAL_CONTENT:                 return "Partial Content";
    case http_status::MULTIPLE_CHOICES:                return "Multiple Choices";
    case http_status::MOVED_PERMANENTLY:               return "Moved Permanently";
    case http_status::FOUND:                           return "Found";
    case http_status::SEE_OTHER:                       return "See Other";
    case http_status::NOT_MODIFIED:                    return "Not Modified";
    case http_status::USE_PROXY:                       return "Use Proxy";
    case http_status::TEMPORARY_REDIRECT:              return "Temporary Redirect";
    case http_status::PERMANENT_REDIRECT:              return "Permanent Redirect";
    case http_status::BAD_REQUEST:                     return "Bad Request";
    case http_status::UNAUTHORIZED:                    return "Unauthorized";
    case http_status::PAYMENT_REQUIRED:                return "Payment Required";
    case http_status::FORBIDDEN:                       return "Forbidden";
    case http_status::NOT_FOUND:                       return "Not Found";
    case http_status::METHOD_NOT_ALLOWED:              return "Method Not Allowed";
    case http_status::NOT_ACCEPTABLE:                  return "Not Acceptable";
    case http_status::PROXY_AUTHENTICATION_REQUIRED:   return "Proxy Authentication Required";
    case http_status::REQUEST_TIMEOUT:                 return "Request Timeout";
    case http_status::CONFLICT:                        return "Conflict";
    case http_status::GONE:                            return "Gone";
    case http_status::LENGTH_REQUIRED:                 return "Length Required";
    case http_status::PRECONDITION_FAILED:             return "Precondition Failed";
    case http_status::PAYLOAD_TOO_LARGE:               return "Payload Too Large";
    case http_status::URI_TOO_LONG:                    return "URI Too Long";
    case http_status::UNSUPPORTED_MEDIA_TYPE:          return "Unsupported Media Type";
    case http_status::RANGE_NOT_SATISFIABLE:           return "Range Not Satisfiable";
    case http_status::EXPECTATION_FAILED:              return "Expectation Failed";
    case http_status::IM_A_TEAPOT:                     return "I'm a teapot";
    case http_status::MISDIRECTED_REQUEST:             return "Misdirected Request";
    case http_status::UNPROCESSABLE_ENTITY:            return "Unprocessable Entity";
    case http_status::UPGRADE_REQUIRED:                return "Upgrade Required";
    case http_status::TOO_MANY_REQUESTS:               return "Too Many Requests";
    case http_status::REQUEST_HEADER_FIELDS_TOO_LARGE: return "Request Header Fields Too Large";
    case http_status::INTERNAL_SERVER_ERROR:           return "Internal Server Error";
    case http_status::NOT_IMPLEMENTED:                 return "Not Implemented";
    case http_status::BAD_GATEWAY:                     return "Bad Gateway";
    case http_status::SERVICE_UNAVAILABLE:             return "Service Unavailable";
    case http_status::GATEWAY_TIMEOUT:                 return "Gateway Timeout";
    case http_status::HTTP_VERSION_NOT_SUPPORTED:      return "HTTP Version Not Supported";
    default:                                           return "Unknown";
  }
}

/**
 * @brief 对端**从来没有给过**状态码。
 *
 * 只在错误路径上出现：h2 上一条流在响应头到达**之前**就被 RST_STREAM 掉
 * （`REFUSED_STREAM` 正是这种），此时交付给调用方的 `status_code` 就是它。
 *
 * 它存在的理由是**不许编**：`uvcpp_http_response` 的默认构造是 `200 OK`，直接
 * 把默认值交出去，调用方会看到一个对端从没说过的 200 配一个非零的 `err` ——
 * 日志里就是"请求失败了，但状态码 200"。0 不是任何合法状态码，
 * `http_status_reason()` 对它返回 `"Unknown"`，看不出歧义。
 *
 * **判据仍然是 `err != 0`**：这个常量只是让"我们没收到过"与"对端说了 200"
 * 在值上分得开，不是让调用方改判据。
 */
const http_status HTTP_STATUS_NONE = static_cast<http_status>(0);

// =========================================================================
// HTTP 版本 — 1.0 / 1.1 走 llhttp，2 与 3 是协商出来的、没有版本行
//
// NOTE: Values use "HV_" prefix to avoid collision with Windows SDK
// macros (HTTP_1_1, HTTP_VERSION_1_1, etc.)
// =========================================================================

enum class uvcpp_http_version : uint8_t {
  HVER_10 = 0,  // HTTP/1.0 (RFC 1945)
  HVER_11 = 1,  // HTTP/1.1 (RFC 7230-7235)
  HVER_20 = 2,  // HTTP/2   (RFC 7540/9113)
  HVER_30 = 3,  // HTTP/3   (RFC 9114)
};

/**
 * @brief Return the protocol string for an HTTP version.
 *
 * h2 是 `"HTTP/2"`，**不是** `"HTTP/2.0"` —— 后者只在早期的
 * `draft-ietf-httpbis-http2` 里出现过，RFC 7540 定稿后就没有 `.0` 了。
 * h3 同理是 `"HTTP/3"`（RFC 9114 §3.1 里的版本标识就是它，同样没有 `.0`）。
 *
 * 注意这个串在 h2 上**没有任何线上面貌**：h2 没有版本行、没有 reason phrase，
 * 版本是 ALPN 协商出来的。它只出现在"把 h2 消息当 h1 排版"的地方（调试输出、
 * `uvcpp_web_request::version_string()`），所以写错不会当场坏掉 —— 正因如此
 * 才要在这里改对，而不是等它被人抄进日志再回头找。
 */
inline const char* uvcpp_http_version_str(uvcpp_http_version v) {
  switch (v) {
    case uvcpp_http_version::HVER_10: return "HTTP/1.0";
    case uvcpp_http_version::HVER_11: return "HTTP/1.1";
    case uvcpp_http_version::HVER_20: return "HTTP/2";
    case uvcpp_http_version::HVER_30: return "HTTP/3";
    default:                          return "HTTP/1.1";
  }
}

// =========================================================================
// HTTP 头类型
// =========================================================================

/**
 * @brief A single HTTP header (key-value pair).
 *
 * The name is stored in lower-case for efficient case-insensitive lookup.
 */
struct http_header {
  std::string name;   ///< Header field name (lower-case)
  std::string value;  ///< Header field value
};

/** @brief Ordered list of HTTP headers. */
using http_headers = std::vector<http_header>;

// =========================================================================
// Header 便捷函数
// =========================================================================

/**
 * @brief 编译期可求长的 C 串长度。
 *
 * C++11 的 constexpr 只能单 return，所以写成递归。**对字面量它折成常量**，
 * 运行期连 strlen 都不剩；对真正的运行期指针它就是一次 strlen。
 *
 * 存在的理由见下面那族 `const char*` 重载：没有它，`"transfer-encoding"`
 * 这种 17 字符的字面量会在每个调用点构造一个堆串。
 */
inline constexpr size_t http_name_len(const char* s, size_t n = 0) {
  return (s != nullptr && *s != '\0') ? http_name_len(s + 1, n + 1) : n;
}

/**
 * @brief ASCII 大写字母→小写；其余字节**原样**返回。查表，不调 libc。
 *
 * 为什么不用 `std::tolower`：`<cctype>` 里那个是 libc 的符号（glibc 上还要先
 * `__ctype_b_loc()` 取表基址），`-O3` 下依然是一次 **PLT 调用**。头名比较是
 * 每请求几十次、每次十来个字节的内循环，这一层调用的开销比比较本身还大 ——
 * 实测（12 个真头名扫一遍，同一进程内三档交替、各取最好一轮）：
 *
 * | 实现 | ns/次 | 相对 |
 * |---|---|---|
 * | `std::tolower` | 39.8 | —— |
 * | 算术版 `(c >= 'A' && c <= 'Z') ? (c \| 0x20) : c` | 9.6 | −76% |
 * | **本表** | 6.8 | **−83%** |
 *
 * 表是**函数内静态常量数组**：常量初值属于静态初始化，编译器不会给它生成
 * 线程安全的初始化守卫（`nm` 里没有 `__cxa_guard_*`），所以这里就是一次下标
 * load，不是"if (没初始化) 初始化一次"。算术版比它慢的那 3 ns 是两条比较加
 * 一个分支的代价 —— 一个字节要落进哪个区间，表已经答了。
 *
 * 只处理 **ASCII**：HTTP 头名按 RFC 7230 §3.2 是 `token`（全 ASCII）。形参是
 * `unsigned char`，于是任何字节都有定义的结果（`std::tolower` 收负的 char 是
 * 未定义行为，这也是这一族一直 cast 的原因）。`tests/unit/http_name_alloc_unit.cpp`
 * 逐字节拿这张表对 `std::tolower`（C locale）—— 256 个字节全覆盖，不是抽样。
 */
inline unsigned char http_lower_ascii(unsigned char c) {
  static const unsigned char kLower[256] = {
        0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  // 0..13
       14,  15,  16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  // 14..27
       28,  29,  30,  31,  32,  33,  34,  35,  36,  37,  38,  39,  40,  41,  // 28..41
       42,  43,  44,  45,  46,  47,  48,  49,  50,  51,  52,  53,  54,  55,  // 42..55
       56,  57,  58,  59,  60,  61,  62,  63,  64,  97,  98,  99, 100, 101,  // 56..69
      102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115,  // 70..83
      116, 117, 118, 119, 120, 121, 122,  91,  92,  93,  94,  95,  96,  97,  // 84..97
       98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,  // 98..111
      112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125,  // 112..125
      126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139,  // 126..139
      140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153,  // 140..153
      154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167,  // 154..167
      168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181,  // 168..181
      182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195,  // 182..195
      196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209,  // 196..209
      210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223,  // 210..223
      224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237,  // 224..237
      238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251,  // 238..251
      252, 253, 254, 255,  // 252..255
  };
  return kLower[c];
}

/**
 * @brief 按 (指针, 长度) 比头名，大小写不敏感。**零分配。**
 *
 * 这是这族函数唯一的比较原语，`const std::string&` 那侧也走它 —— 免得同一套
 * 小写化逻辑存在两份、日后只改一边。
 *
 * 逐字节走 `http_lower_ascii()`（一张表），**不调 `std::tolower`** —— 理由与
 * 实测数都在那个函数上面。
 *
 * RFC 7230 Section 3.2: header field names are case-insensitive.
 */
inline bool http_name_iequal(const char* a, size_t an,
                             const char* b, size_t bn) {
  if (an != bn) return false;
  for (size_t i = 0; i < an; ++i) {
    if (http_lower_ascii(static_cast<unsigned char>(a[i])) !=
        http_lower_ascii(static_cast<unsigned char>(b[i])))
      return false;
  }
  return true;
}

// -------------------------------------------------------------------------
// 下面四个函数各有两个形态：一个收 `const std::string&`（既有，一行未动），
// 一个收 `const char*`。
//
// **为什么必须有 `const char*` 那个**：形参是 `const std::string&` 时，字面量
// 在**调用点**就要构造一个 `std::string`；而 MSVC 的 SSO 上限是 15
// （`xstring`: `_BUF_SIZE = 16/sizeof(char)`、`_Small_string_capacity = _BUF_SIZE-1`），
// 于是 `"transfer-encoding"`(17)、`"content-encoding"`(16)、
// `"access-control-allow-origin"`(27) 这些**每一次调用都是一次堆分配 + 一次释放**，
// 而那个串马上就被扔掉。热路径上每请求 6~8 次。
//
// **调用点一行都不用改**：字面量在重载解析里对 `const char*` 是精确匹配，对
// `const std::string&` 要走一次用户定义转换 ⇒ 前者胜出。`std::string` 实参则
// 只能绑既有那个（没有 `std::string` → `const char*` 的隐式转换）。两边都不含糊。
//
// 值那一侧**同样要**。这里原先写着「全仓扫过，这族调用里的长字面量全部落在
// **名字**位置，值位置一个都没有」—— 那句是错的：值位置确实有，只是不在
// `set_header` 的调用点上，而在 `uvcpp_web_response::body()` 的 `ct` 实参上
// （`text()` 传 25 字符、`html()` 24、`json()` / `json_str()` 31，见
// `uvcpp_web_response.cpp`）。所以这族里 `http_set_header` 有**三个**形态，
// 第三个就在下面。
// -------------------------------------------------------------------------

/**
 * @brief Case-insensitive string equality for header names.
 */
inline bool http_name_equal(const std::string& a, const std::string& b) {
  return http_name_iequal(a.data(), a.size(), b.data(), b.size());
}

/** @copydoc http_name_equal(const std::string&, const std::string&) */
inline bool http_name_equal(const std::string& a, const char* b) {
  return http_name_iequal(a.data(), a.size(), b, http_name_len(b));
}

/** @copydoc http_name_equal(const std::string&, const std::string&) */
inline bool http_name_equal(const char* a, const std::string& b) {
  return http_name_iequal(a, http_name_len(a), b.data(), b.size());
}

/** @copydoc http_name_equal(const std::string&, const std::string&) */
inline bool http_name_equal(const char* a, const char* b) {
  return http_name_iequal(a, http_name_len(a), b, http_name_len(b));
}

/**
 * @brief Find a header value by name (case-insensitive).
 * @param hdrs  Header list to search.
 * @param name  Header name to find (case-insensitive).
 * @param def   Default value if not found.
 * @return      The header value, or @p def if not present.
 */
inline std::string http_get_header(const http_headers& hdrs,
                                    const std::string& name,
                                    const std::string& def = "") {
  for (const auto& h : hdrs) {
    if (http_name_equal(h.name, name)) return h.value;
  }
  return def;
}

/** @copydoc http_get_header(const http_headers&, const std::string&, const std::string&) */
inline std::string http_get_header(const http_headers& hdrs,
                                    const char* name,
                                    const std::string& def = "") {
  const size_t n = http_name_len(name);
  for (const auto& h : hdrs) {
    if (http_name_iequal(h.name.data(), h.name.size(), name, n)) return h.value;
  }
  return def;
}

/**
 * @brief Find a header value by name, **writing into an existing string**.
 *
 * 与 `http_get_header()` 的差别只有一个，但热路上它是决定性的：那个按**值**
 * 返回（`return h.value;`），值一过 SSO 线就是一次 malloc —— 调用方再用它
 * 赋值 / 移动，那一份就白扔了。这里 `out = h.value`，`out` 是**连接级**成员，
 * 带着上一条请求留下的容量，够用时一次分配都不做，一条连接上只有第一次
 * （以及遇到更长的值时）才真的分配。
 *
 * 头不存在时 `out` 会被**清空**（不是保持原值）：调用方要的是"这条请求的这个
 * 头是什么"，上一条请求的值不该留在这儿。返回值表示有没有这个头。
 */
inline bool http_get_header_into(const http_headers& hdrs, const char* name,
                                 std::string& out) {
  const size_t n = http_name_len(name);
  for (const auto& h : hdrs) {
    if (http_name_iequal(h.name.data(), h.name.size(), name, n)) {
      out = h.value;
      return true;
    }
  }
  out.clear();
  return false;
}

/** @copydoc http_get_header_into(const http_headers&, const char*, std::string&) */
inline bool http_get_header_into(const http_headers& hdrs,
                                 const std::string& name, std::string& out) {
  for (const auto& h : hdrs) {
    if (http_name_equal(h.name, name)) {
      out = h.value;
      return true;
    }
  }
  out.clear();
  return false;
}

/**
 * @brief Check whether a header exists (case-insensitive).
 */
inline bool http_has_header(const http_headers& hdrs, const std::string& name) {
  for (const auto& h : hdrs) {
    if (http_name_equal(h.name, name)) return true;
  }
  return false;
}

/** @copydoc http_has_header(const http_headers&, const std::string&) */
inline bool http_has_header(const http_headers& hdrs, const char* name) {
  const size_t n = http_name_len(name);
  for (const auto& h : hdrs) {
    if (http_name_iequal(h.name.data(), h.name.size(), name, n)) return true;
  }
  return false;
}

/**
 * @brief 头表的容量提示：**头一次真往里放东西之前**调一次，一次要到 4 个位置。
 *
 * 为什么是"懒"的、而不是在 `uvcpp_http_response` 的构造函数里预留：
 * 响应对象每个请求都要造一个（webapp 侧那个是 `uvcpp_web_context` 按值持有的
 * 成员），但其中**有一份只当控制位用** —— HTTP 层的 `dispatch_h1_request()` /
 * `dispatch_h2_request()` 造一个栈上的 `resp` 传给兜底 handler，而 webapp 的
 * 兜底 handler 只写它的 `deferred` 一个字段、头表一个字节都不放
 * （响应由它自己那份 `uvcpp_web_context::resp_` 出）。构造函数里预留的话，
 * 那一份每请求白付一次 256 B 分配（分配普查里那是 2.00 次/请求里的一次）。
 *
 * 放在"第一次真的插入"这一刻，对**会放头**的对象语义与预留 4 个完全一样
 * （一条最普通的响应是 content-type + content-length + connection，三次
 * `push_back` 的扩容 1→2→4 正是它要避开的），而对不放头的对象是零成本。
 *
 * ★ 直接 `push_back` 的地方要自己调一次 —— 漏了**不会出错**，只是那个对象
 * 退化成"1→2→4 三次扩容"。目前只有三处：`uvcpp_web_response::add_header()`
 * 的两个重载（追加语义，Set-Cookie 这类多值头）、`uvcpp_h2_session.cpp` 里
 * 从 h2 帧填响应头的那一处、以及 `uvcpp_http_client.cpp` 填请求头的那一处。
 */
inline void http_reserve_headers(http_headers& hdrs) {
  if (hdrs.capacity() == 0) hdrs.reserve(4);
}

/**
 * @brief Set or overwrite a header (case-insensitive match on name).
 */
inline void http_set_header(http_headers& hdrs, const std::string& name,
                             const std::string& value) {
  for (auto& h : hdrs) {
    if (http_name_equal(h.name, name)) {
      h.value = value;
      return;
    }
  }
  http_reserve_headers(hdrs);
  hdrs.push_back({name, value});
}

/** @copydoc http_set_header(http_headers&, const std::string&, const std::string&) */
inline void http_set_header(http_headers& hdrs, const char* name,
                             const std::string& value) {
  const size_t n = http_name_len(name);
  for (auto& h : hdrs) {
    if (http_name_iequal(h.name.data(), h.name.size(), name, n)) {
      h.value = value;
      return;
    }
  }
  // 走到这里才真的插入，头名这时候必须被拷下来（外面那个字面量不归我们管）。
  http_reserve_headers(hdrs);
  hdrs.push_back({std::string(name, n), value});
}

/**
 * @brief 名字与**值**都是字面量时的版本。
 *
 * 上面那段末尾说的"值那一侧也有"，落点就在这——长字面量在 `uvcpp_web_response`
 * 的 `text()`(25) / `html()`(24) / `json()`(31) / `json_str()`(31) 里被传给
 * `body()` 的 `ct` 形参，而那一版 `ct` 收的是 `const std::string&`：
 *
 *   `resp.text("ok")` → `body("ok", 2, "text/plain; charset=utf-8")`
 *                       ↑ 调用点先建一个 25 字符的临时串（第 1 次分配）
 *                       → `push_back` 把值拷进 `http_header.value`（第 2 次）
 *
 * **那是 benchmark 自己在跑的两条路由**（`GET /text`、`GET /json`）。
 *
 * 这一版让两个成员各自从 C 串**就地构造**，再移动进向量 ⇒ 两次分配降到一次
 * （留下的那一次是头表必须持有的那份值，省不掉）。`std::string` 实参照旧绑
 * 上面那两条，行为不变。
 */
inline void http_set_header(http_headers& hdrs, const char* name,
                            const char* value) {
  const size_t n = http_name_len(name);
  for (auto& h : hdrs) {
    if (http_name_iequal(h.name.data(), h.name.size(), name, n)) {
      h.value = value;
      return;
    }
  }
  http_reserve_headers(hdrs);
  hdrs.push_back(http_header{std::string(name, n), value});
}

// =========================================================================
// `Accept-Encoding` → 预压缩孪生文件后缀
// =========================================================================
//
// 两个静态器（协议层的 `uvcpp_static_server` 与应用层的 `uvcpp_web_static`）
// 都要做同一件事：客户端说它收 brotli，盘上恰好躺着 `foo.br`，就把那份发出去。
// 判定规则是 RFC 9110 的，两边**必须逐字一致** —— 同一条 `Accept-Encoding`
// 在两个监听器上选出不同的表示，是那种"看日志永远看不出来"的偏差。所以实现
// 只有这一份，放在这一层（`web` 是协议层，`webapp` 在它上面，反向不成立）。
//
// 返回一张**有序**候选表而不是一个后缀：客户端能收的常常不止一种，而盘上备了
// 哪几种是构建期的事。只认首选的话，"这个资源只压过 `.gz`" 就会退化成"这个
// 资源没压过"、把原文件发出去 —— 而次优的那份本来就在盘上。nginx 同时挂
// brotli 与 gzip_static 两个模块时、Caddy 写 `precompressed br gzip` 时，
// 都是**按序取第一个存在的**，这里照做。

/// `q=` 的值。只认 `[0-9]*[.[0-9]*]`：本层只拿它做"是不是 0"和两个编码之间的
/// 先后比较，`strtod` 会拖进 locale 语义，为这点事不值当。解析不出数字时按
/// RFC 9110 §12.4.2 的宽松读法当作 1（"没说就是全要"）。
inline double http_parse_quality(const std::string& v) {
  double x = 0.0;
  size_t i = 0;
  bool any = false;
  for (; i < v.size() && v[i] >= '0' && v[i] <= '9'; ++i) {
    x = x * 10.0 + static_cast<double>(v[i] - '0');
    any = true;
  }
  if (i < v.size() && v[i] == '.') {
    ++i;
    double f = 0.1;
    for (; i < v.size() && v[i] >= '0' && v[i] <= '9'; ++i) {
      x += static_cast<double>(v[i] - '0') * f;
      f *= 0.1;
      any = true;
    }
  }
  if (!any) return 1.0;
  return x > 1.0 ? 1.0 : x;  // RFC 9110：q 落在 [0,1]，越界按 1 收
}

/// 去掉首尾 OWS（`Accept-Encoding` 的分隔符两侧到处是空格，且常带 CRLF 折行）。
inline std::string http_trim_ows(const std::string& s) {
  size_t b = 0;
  size_t e = s.size();
  while (b < e) {
    const char c = s[b];
    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') ++b;
    else break;
  }
  while (e > b) {
    const char c = s[e - 1];
    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') --e;
    else break;
  }
  return s.substr(b, e - b);
}

/**
 * @brief 从 `Accept-Encoding` 里挑出预压缩孪生文件的后缀，按优先级排好。
 *
 * `out[0]`/`out[1]` 写入 `".br"` / `".gz"`，返回**候选个数**（0/1/2）。返回 0
 * 表示不用孪生文件、发原文件。只认 `br` 与 `gzip`（含 `x-gzip` 这个历史别名）
 * 两个 token：本仓的压缩器只会 deflate，所以 `deflate` 这个 token 对应的是
 * **实时压缩**那条路，不在孪生文件里管。
 *
 * `q=0` 是明确拒绝，即便它是唯一被声明的编码也不选它。同 `q` 时优先 `br` ——
 * 两份产物都是我们自己发出去的字节，brotli 在同一份资源上更小（本仓
 * `data/static` 那 20 个文件上平均小 16%）。`*` 按 RFC 9110 §12.5.3 匹配所有
 * 未列出的编码，这里让它同时兜住两者。
 *
 * @param header `Accept-Encoding` 的值（可空）。
 * @param out    长度 2 的输出数组，调用方负责提供。
 * @return 写进 `out` 的候选个数。
 */
inline size_t http_pick_precompressed_variants(const std::string& header,
                                               std::string out[2]) {
  out[0].clear();
  out[1].clear();
  bool br_ok = false, gz_ok = false, star_ok = false;
  double br_q = 0.0, gz_q = 0.0, star_q = 0.0;

  size_t pos = 0;
  while (pos <= header.size()) {
    const size_t comma = header.find(',', pos);
    const std::string raw = http_trim_ows(header.substr(
        pos, comma == std::string::npos ? std::string::npos : comma - pos));
    pos = (comma == std::string::npos) ? header.size() + 1 : comma + 1;
    if (raw.empty()) continue;

    std::string name = raw;
    double q = 1.0;
    const size_t semi = raw.find(';');
    if (semi != std::string::npos) {
      name = http_trim_ows(raw.substr(0, semi));
      // 参数段可能不止一个（`gzip;q=0.8;foo=bar`），逐个找 `q=`。
      size_t p = semi + 1;
      while (p <= raw.size()) {
        const size_t sc = raw.find(';', p);
        const std::string one = http_trim_ows(raw.substr(
            p, sc == std::string::npos ? std::string::npos : sc - p));
        p = (sc == std::string::npos) ? raw.size() + 1 : sc + 1;
        if (one.size() > 2 && (one[0] == 'q' || one[0] == 'Q') && one[1] == '=') {
          q = http_parse_quality(one.substr(2));
        }
      }
    }
    if (name.empty()) continue;

    if (http_name_iequal(name.data(), name.size(), "br", 2)) {
      if (q > 0.0) { br_ok = true; br_q = q; }
    } else if (http_name_iequal(name.data(), name.size(), "gzip", 4) ||
               http_name_iequal(name.data(), name.size(), "x-gzip", 6)) {
      if (q > 0.0) { gz_ok = true; gz_q = q; }
    } else if (name == "*") {
      if (q > 0.0) { star_ok = true; star_q = q; }
    }
  }

  if (star_ok) {  // 未列出的按通配的 q 收；显式声明过的以显式那份为准
    if (!br_ok) { br_ok = true; br_q = star_q; }
    if (!gz_ok) { gz_ok = true; gz_q = star_q; }
  }
  // 排序只在这三个组合里有意义；同 q 时 br 在前（本仓 `data/static` 上平均小 16%）。
  size_t n = 0;
  if (br_ok && gz_ok) {
    out[0] = (br_q >= gz_q) ? std::string(".br") : std::string(".gz");
    out[1] = (br_q >= gz_q) ? std::string(".gz") : std::string(".br");
    n = 2;
  } else if (br_ok) {
    out[0] = ".br";
    n = 1;
  } else if (gz_ok) {
    out[0] = ".gz";
    n = 1;
  }
  return n;
}

}  // namespace uvcpp

#endif  // UVCPP_WEB_ENABLE
#endif  // SRC_WEB_UVCPP_HTTP_COMMON_H
