﻿/**
 * @file src/net/uvcpp_tcp_server.h
 * @brief Higher-level TCP server with bind/listen convenience and auto client management.
 * @author zhuweiye
 * @version 1.0.0
 *
 * Wraps uvcpp_tcp to provide a simple bind+listen API with automatic
 * callback setup for accepted clients (default write/close handlers,
 * missing-read-callback warnings). By default (or with `set_loops(1)`) it is a
 * single-threaded event-loop object — IO-intensive work should be offloaded via
 * uvcpp_work. `set_loops(n > 1)` turns it into one acceptor loop plus n-1
 * dedicated worker threads (see that method's docs).
 */

#pragma once
#ifndef SRC_NET_UVCPP_TCP_SERVER_H
#define SRC_NET_UVCPP_TCP_SERVER_H

#include <uvcpp/uvcpp_config.h>

#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <uv.h>
#include <vector>
#include <handle/uvcpp_loop.h>
#include <handle/uvcpp_tcp.h>
#include <net/uvcpp_tcp_client.h>

namespace uvcpp {

class uvcpp_loop_worker;

/**
 * @brief Bitmask status flags for TCP server lifecycle.
 */
enum uvcpp_tcp_server_status : int {
  TCP_SERVER_NONE      = 0x00,  ///< Initial state
  TCP_SERVER_LISTENING = 0x02,  ///< Actively accepting connections
  TCP_SERVER_STOPPING  = 0x04,  ///< stop() called, closing
  TCP_SERVER_STOPPED   = 0x08,  ///< Fully stopped
  TCP_SERVER_ERROR     = 0x10   ///< Error occurred (see last_error_code)
};

/**
 * @brief Application-layer TCP server wrapping uvcpp_tcp.
 *
 * Provides convenience bind (IPv4/IPv6) and listen with automatic
 * per-client callback management.
 *
 * Before the user's connection callback runs, each new client is:
 * - **registered and given a close manager** that removes it from the
 *   server and deletes it when the connection closes. This happens
 *   unconditionally — the user's own `set_on_close()` is a separate,
 *   purely observational slot and can never suppress it.
 * - **started reading** (`set_auto_read()`, default on). Reading is what
 *   makes a peer disconnect visible at all: the `nread < 0` branch of the
 *   read callback is the only place it is detected. Without it a closed
 *   connection would never be noticed, never released, and never reported
 *   through the close callbacks — a silent per-connection leak. Registering
 *   your own reader in the connection callback (via `read_start()` or
 *   `read_start_events()`) replaces the automatic one.
 * - Write buffers are automatically freed by uvcpp_write regardless of
 *   whether a user callback was provided.
 *
 * Prefer `set_read_callback()` over per-connection `read_start()`: it hands
 * you `net_read_result` events, which distinguish received data from a
 * graceful peer close (`PEER_CLOSED`) and from a read error (`READ_ERROR`,
 * carrying the libuv error code). The raw callback cannot — it receives
 * nothing at all in those last two cases.
 *
 * IMPORTANT: All callbacks (connection, read, write, close) run on
 * the event-loop thread. Do NOT perform IO-intensive work (file I/O,
 * heavy computation, blocking calls) inside any callback — it will block
 * the entire event loop. Use uvcpp_work to offload heavy tasks:
 *
 * @code
 *   uvcpp_work* w = new uvcpp_work();
 *   w->queue_work(server->get_loop(),
 *     [](uvcpp_work* w) {
 *       // Heavy work here (runs on worker thread)
 *     },
 *     [](uvcpp_work* w, int status) {
 *       // Process results, send response (runs on loop thread)
 *       delete w;
 *     });
 * @endcode
 *
 * Simple data checks and async writes are fine inline. Do NOT use
 * sync write_wait/read_wait inside any callback: they block the loop thread, so one
 * slow peer stalls *every* connection on it. Mind the trap — these take an optional
 * completion callback, and **omitting it is precisely what makes them synchronous**
 * (`uvcpp_tcp_client.h`: a null callback behaves like `write_wait(data, len, 30000)`).
 * Inside a callback always pass one, as the example below does.
 *
 * Usage:
 * @code
 *   uvcpp_tcp_server server;
 *   server.bind("0.0.0.0", 8080);
 *
 *   // 一份读回调，所有连接共用（框架层读：事件带语义）
 *   server.set_read_callback([](uvcpp_tcp_client& c, const net_read_result& r) {
 *     if (r.is_data()) {
 *       // 收到数据（keep this fast!）
 *       c.write(r.data, r.size(), [](int) {});   // 回显；传回调才是异步，别传 nullptr
 *     } else if (r.event == net_read_event::PEER_CLOSED) {
 *       // 对端正常收工
 *     } else {
 *       // 读错误，r.error 是 libuv 错误码
 *     }
 *   });
 *
 *   server.listen([](uvcpp_tcp_client* client) {
 *     // 连接已登记、已起读、断开时会自动释放 —— 这里通常什么都不用做
 *     (void)client;
 *   });
 *   server.run(UV_RUN_DEFAULT);
 * @endcode
 */
class UVCPP_API uvcpp_tcp_server {
 public:
  UVCPP_DEFINE_FUNC(uvcpp_tcp_server)
  UVCPP_DEFINE_COPY_FUNC_DELETE(uvcpp_tcp_server)

  /**
   * @brief 用一条**外部**事件循环（与 `uvcpp_tcp_client(uvcpp_loop*)` 同一
   *        约定：本对象不拥有它，析构时也不关不删）。
   *
   * 为什么需要：`set_loops(n > 1)` 的工作循环由本类自己起，但**0 号循环**
   * （接受者）原先只能是本类自建的那一条。上层要在自己那条循环上收一条
   * 临时监听器时（SOCKS5 的 BIND、需要与既有连接同循环的辅助服务），
   * 没有办法把那个监听器放进调用方的循环 —— 于是有了这个构造。
   *
   * @warning 外部循环必须**活得比本对象长**，并且 `run()` 由调用方负责。
   */
  explicit uvcpp_tcp_server(uvcpp_loop* loop);

  // -----------------------------------------------------------------
  // Accessors
  // -----------------------------------------------------------------

  /** @brief Return the underlying uvcpp_tcp handle. */
  uvcpp_tcp* get_tcp();

  /** @brief Return the internal event loop. */
  uvcpp_loop* get_loop();

  /** @brief Return the current status bitmask. */
  int get_status() const;

  /** @brief Check whether all given status flags are set. */
  bool has_status(int flags) const;

  /** @brief Return the last recorded error code (libuv errno). */
  int get_last_error() const;

  // -----------------------------------------------------------------
  // Bind
  // -----------------------------------------------------------------

  /**
   * @brief Bind to an address, auto-detecting IPv4 vs IPv6.
   * @param ip   IPv4 or IPv6 address string.
   * @param port Port number.
   * @return 0 on success, libuv error code on failure.
   */
  int bind(const char* ip, int port);

  /** @brief Bind to an IPv4 address. */
  int bindIpv4(const char* ip, int port);

  /** @brief Bind to an IPv6 address. */
  int bindIpv6(const char* ip, int port);

  // -----------------------------------------------------------------
  // Listen
  // -----------------------------------------------------------------

  /**
   * @brief Start listening for incoming connections.
   *
   * @param connection_cb  Called for each new connection with a
   *                       uvcpp_tcp_client* whose TCP handle has
   *                       already been accepted. The client is in
   *                       CONNECTED | READABLE | WRITABLE state.
   *
   *                       Thread safety: this callback runs on
   *                       the event-loop thread. Do not block, do
   *                       not perform IO-intensive work. Use
   *                       uvcpp_work::queue_work() for heavy tasks.
   *
   *                       Simple data inspection and async writes
   *                       are safe. Do NOT use sync write_wait or
   *                       read_wait inside this or any event-loop
   *                       callback.
   *
   * @param backlog  Listen backlog (default 128).
   * @return 0 on success, libuv error code on failure.
   */
  int listen(std::function<void(uvcpp_tcp_client*)> connection_cb,
             int backlog = 128);

  // -----------------------------------------------------------------
  // 每条连接的 TCP_NODELAY
  // -----------------------------------------------------------------

  /**
   * @brief 接受一条连接之后要不要给它设 `TCP_NODELAY`。默认**开**。
   *
   * 为什么默认开、而且默认值本身是这次改动的一部分：libuv 建出来的 socket
   * **不设** `TCP_NODELAY`，于是 Nagle 算法是开的 —— 一次应答只要被写成两段
   * （每段都小于 MSS），第二段就会被压在发送缓冲里，等对端的 ACK 才放行；
   * 而对端此刻恰好没有数据要回，它走的是 Linux 的延迟 ACK（40 ms）⇒
   * **这一笔应答平白多出 40 ms**。
   *
   * 这不是理论推演：h2 上的 gRPC 应答正是两段（头块 + DATA 一段、尾随头一段），
   * 而 h1 那条路一直是"整条报文一次 `uv_write`"、一段就够 —— 于是同一台服务器、
   * 同一个 `h2load`、同一条回环上，h1 路由的 `request` 中位数是 **21 µs**，
   * h2c 上的 gRPC 路由是 **41.00 ms**，`-c 1 -m 1` 五秒只出 121 个请求。
   * 开了 `TCP_NODELAY` 之后同一格降到 **29 µs**、五秒出 **147 447** 个。
   * 所以这个缺陷在 h2 之前一直不可见（见 `CHANGELOG.md`）。
   *
   * **它只在"一条连接上一个请求在途"时咬人。** `-c 256 -m 100` 那种持续流水下
   * 量不出差别（两臂落在彼此的轮间散布里）：ACK 一直在流，Nagle 最多压住一个
   * RTT（回环上几十 µs），压不到 40 ms。所以它是**低并发请求/应答的时延开关**，
   * 不是吞吐旋钮 —— 高并发档上别指望它给出数字。
   *
   * 关掉它的场景是**自己成批小写**的调用方：Nagle 会把它们合并成满 MSS 的段，
   * 省包。请求/应答型服务端不属于这一类，nginx 的 `tcp_nodelay`、Go 的
   * `net/http` 也都是默认开。
   *
   * @warning 必须在 `listen()`（以及 `set_loops(n > 1)`，如果要用）**之前**调。
   * 这个值在每次 accept 时被读，运行中改它只会影响之后新落上来的连接，而
   * 多循环下它还会被 worker 线程并发读 —— 先设好再放行，与
   * `set_loop_start_hook()` 是同一条纪律。
   */
  void set_tcp_nodelay(bool on);

  /// @brief 见 `set_tcp_nodelay()`。默认 true。
  bool tcp_nodelay() const;

  // -----------------------------------------------------------------
  // 多循环（接受者 + 工作线程）
  // -----------------------------------------------------------------

  /**
   * @brief 设定工作循环数。**不调用（或 `set_loops(1)`）= 今天的行为**。
   *
   * n 是**循环总数**，含调用线程跑的那一条：0 号是接受者（就是 `get_loop()`），
   * 1..n-1 号各有一条**专用 `std::thread`** 跑自己的循环（不是 libuv 线程池）。
   * **n 条循环各跑各的，这一点两端一致；两端不一致的是"新连接怎么落到某一条
   * 循环上"**，而且那件事是**运行时探测**出来的（同一个二进制在不同平台上不
   * 一样），不是编译期分叉。两种形状：
   *
   * - **内核分流**（平台支持 `UV_TCP_REUSEPORT` 时，Linux 是）：n 条循环各自绑
   *   一个监听句柄、抢同一个端口，内核按四元组把新连接分给其中任意一个 ——
   *   **0 号自己也收属于它的那一份**，就地收下，不转手。哪条连接落哪条循环由
   *   内核哈希决定：**不保证均匀、也不保证每条循环都能分到**，保证的只有"总数
   *   守恒、每条连接只落一处"（`sum(client_count_at(i)) == client_count()`）。
   * - **接受者 + 转手**（Windows；以及平台不支持那个标志时的回落）：0 号只接受
   *   和分发，每条连接按**显式轮转**交给 `1..n-1` 号，**一条不留在接受者上**；
   *   第 i 条连接必然落到 `1 + (i % (n-1))`，分布是确定的。
   *
   * 想知道这次是哪种：**`is_fanout()`**。这与可观测行为直接相关
   * （分流下 `client_count_at(0)` 非 0，`on_connection` 也会跑在 0 号线程上），
   * 所以别把两端写进同一套判据。回落发生时只在 stderr 打一行提示，不改变
   * 返回值 —— `set_loops()` 的成与不成不看这个。
   *
   * 转手怎么做的（每个平台各自的机制）见 `net/uvcpp_socket_handoff.h`。
   *
   * ## 装上之后，谁在哪个线程上
   *
   * - `on_connection`、读/写/关闭回调都在**那条连接自己的循环线程**上跑；
   *   n>1 时它们**会并发**（不同连接在不同线程），共享状态要自己加锁。
   * - `take_client()` / `return_client()` / `owns_client()` / `pause_read()` /
   *   `resume_read()` 管的是**登记**，登记表是加锁的，所以从任何线程调都对；
   *   但**驱动一条连接**（`write` / `read_start` / `close`）仍然只能在它自己
   *   那条循环的线程上 —— 也就是在它自己的回调里，或者用工作循环的邮箱把活儿
   *   挪过去。跨线程直接驱动一条连接是未定义行为。
   * - `set_read_callback()` / `set_auto_read()` / `set_ssl_context()` /
   *   `set_tls_handshake_timeout_ms()` 写的东西是**工作线程读**的，所以必须在
   *   `listen()` **之前**设好，之后再改就是数据竞争。
   * - `close_all_clients()` 在 n>1 时对别的循环是**异步发起**的（见该函数的说明）。
   *
   * ## Windows 上这条路的代价与边界
   *
   * 转手走 `WSADuplicateSocketW` + `WSASocketW(FROM_PROTOCOL_INFO)` + `uv_tcp_open`
   * —— libuv 眼里 **imported** 的一条血统。**"imported 才是问题所在"是错的**：
   * 闸是 `UV_HANDLE_SYNC_BYPASS_IOCP`，而它只在 worker 侧那次
   * `CreateIoCompletionPort` **成功**时才置（`libuv:win/tcp.c:103-110`、`:117-124`），
   * 那取决于**源 socket 有没有被关联过**。
   *
   * 本库这条转手的源是 `uv_accept` 出来的（**已关联**，`win/tcp.c:662` 那次
   * `imported=0` 的关联）⇒ worker 侧关联必然 `ERROR_INVALID_PARAMETER`（87）
   * ⇒ `UV_HANDLE_EMULATE_IOCP` ⇒ BYPASS **恒 0** ⇒
   * `UV_SUCCEEDED_WITHOUT_IOCP`（`libuv:win/req-inl.h:69`，**只查这一个位**）恒假
   * ⇒ `libuv/libuv#5282` 那一族在**这条**路上没有入口。外部贡献者的仪器在这条腿上
   * 读到 worker 句柄 `flags=0x8e088`；`0x6f08c`（BYPASS=1）是**另一条血统**
   * ——「master 裸 `accept()` 拿到再 dup」，也就是多进程那条形状。
   *
   * **代价是真的，只是落在别处**：EMULATE 意味着这条连接上每一笔 I/O 都走事件句柄
   * 那条模拟路。实测**库侧**约 **25~27%**（单循环 / 8 连接），端到端台架上只值
   * 约 2.5% —— 两个数**量程不同，别单独引**，见 `doc/net-guide.md` §4.2/§4.3。
   *
   * 上面那句"没有入口"是**结构**判断（那一族唯一的闸恒假），**不是**"这条路已经
   * 验过没有别的问题"。机制本身仍未定，证据包与复现装置见
   * `doc/worker-process-design.md` §9。
   *
   * @param n 循环总数，取 1..64。
   * @return 0 成功；`UV_EINVAL` n 越界；`UV_EBUSY` 已经 `listen()` 过，或者
   *         已经用 `n > 1` 装过一遍（装好之后不能再改）。`n == 1` 是幂等的
   *         空操作 —— 它什么都不建，所以随时返回 0。
   *
   * @warning 必须在 `listen()` 之前调用。工作线程是在**本函数里**起的，所以
   *          调用之后（哪怕还没 `listen()`）就已经有 n−1 条线程在跑了。
   */
  int set_loops(int n);

  /**
   * @brief 给每条工作循环装一个"就绪"钩子：**在 worker 线程上、那条循环开始跑
   *        之前**各调一次，参数是循环号与那条循环。
   *
   * **只对 1..n-1 号调**。0 号是接受者，它就是 `get_loop()`，由调用方在自己的
   * 线程上初始化 —— 那里没有"就绪"可言，调用方本来就掌握时机。
   *
   * 用途：属主要在每条工作循环上建**只能建在循环线程上的**句柄（`uv_async` /
   * `uv_timer`），并且要保证在**任何连接落上来之前**建好。`set_loops()` 返回时
   * 工作线程已经在跑了，所以这是唯一插得进去的地方。
   *
   * 时序保证：钩子跑在 worker 放行 `start()` 之前 ⇒ **`set_loops()` 返回时，
   * 所有钩子都已经跑完**。所以"先 `set_loops()` 再 `listen()`"这个顺序本身就
   * 保证了"连接到达时钩子已经跑过"。
   *
   * @param fn 钩子；传空函数则等同于没装（不产生额外开销 —— `n == 1` 时本来
   *           也没有工作线程可挂钩子）。
   *
   * @warning 必须在 `set_loops()` 之前设。装晚了（工作线程已经在跑）它不会
   *          被调用，也不会报错 —— 那正是"配了却没生效"这种最难查的形状，
   *          所以这条约束与 `set_ssl_context()` 那条同级。
   */
  void set_loop_start_hook(std::function<void(int, uvcpp_loop*)> fn);

  /**
   * @brief 给每条工作循环装一个"退出前"的钩子：**在 worker 线程上、那条循环
   *        已经跑完、内存还没释放的时候**各调一次，参数是循环号与那条循环。
   *
   * 与 `set_loop_start_hook()` 对称 —— 那个管"循环起来时要有的东西"，这个管
   * "循环走之前必须由它自己收掉的东西"。同样**只对 1..n-1 号调**：0 号是接受者，
   * 它的循环归调用方自己。
   *
   * 为什么必须有它：工作循环的退出路径是 net 自己走完的（排空邮箱 → 关本循环
   * 的连接 → 泵完挂起的关闭回调 → `uv_loop_close()` + 释放）。属主建在那条循环
   * 上的句柄（`uv_async` / `uv_timer`）不归 net 管，而它们**必须在循环内存被
   * 释放之前**关掉：关晚了是往一块已经还回去的内存上写 `uv_close`（UAF），不关
   * 则 `uv_loop_close()` 撞 `UV_EBUSY`、**整块循环内存泄漏**（`~uvcpp_loop` 那条
   * 有意泄漏）。两者之间没有第三条路，所以属主得有一处能收。
   *
   * 顺序是定的：**net 自己那份（关本循环的连接）先跑完，属主的钩子后跑** ——
   * 钩子看到的登记表已经是空的，"连接都没了"这条前提不需要它自己去确认。
   *
   * 钩子里该做的只有"关句柄 / 放掉只属于这条循环的资源"。**不要停循环、不要
   * 投递新任务、不要阻塞**：那时 `uv_run` 已经返回，循环只剩"把挂起的关闭回调
   * 放完"这一件事，线程体会接着泵几轮 `UV_RUN_NOWAIT` 然后关闭循环。
   *
   * @param fn 钩子；传空函数则等同于没装。
   *
   * @warning 必须在 `set_loops()` 之前设（同 `set_loop_start_hook()`：工作线程
   *          已经起来之后再装不会被调用，也不会报错）。
   */
  void set_loop_exit_hook(std::function<void(int, uvcpp_loop*)> fn);

  /** @brief 循环总数（1 + 工作循环数）。没调过 `set_loops()` 就是 1。 */
  int loop_count() const;

  /**
   * @brief 这次 `n > 1` 走的是**哪条形状**：`true` = 内核分流（n 条循环各自
   *        绑一个监听句柄抢同一个端口，0 号也承载连接），`false` = 接受者 +
   *        转手（0 号一条都不留）。
   *
   * **运行时探测的结果，不是编译期常量**：同一个二进制在不同平台上可能不同
   * （`UV_TCP_REUSEPORT` 在 Linux 上给得出来，在 Windows 上 libuv 无条件拒绝，
   * 在 macOS 上 `uv__sock_reuseport()` 没有实现）。判据要看这个值决定断言哪
   * 一套，别拿 `#ifdef` 猜平台。
   *
   * `n == 1`（含从没 `set_loops()` 过）时恒为 `false` —— 那条路上没有分流可
   * 言，0 号就地接受并处理，与不调 `set_loops()` 逐字节相同。
   *
   * 绑定成功之后才有意义（`bind()` 之前恒为 `false`）。
   */
  bool is_fanout() const;

  /**
   * @brief **强制**走「接受者 + 转手」，即使本平台支持 `UV_TCP_REUSEPORT`。
   *
   * 为什么要有它：POSIX 那条转手路（`uvcpp_socket_handoff.cpp` 的 `::dup()` 支）
   * 在本仓**没有任何一条腿留下过正证据** —— Windows 开发机上它根本编不到
   * （在 `#else` 里）；Linux（本机 VM 与 CI）上 `UV_TCP_REUSEPORT` 绑得上 ⇒
   * `is_fanout()` 恒为真 ⇒ 永不走转手；只有 macOS 会因 `uv__sock_reuseport()`
   * 没实现而**回落**到它，而"macOS 真的回落了吗"本身没人验过。开了这个开关，
   * 同一条用例就能把**两条腿各跑一遍**：`set_handoff_forced(true)` ⇒
   * `is_fanout()` 必为 `false`，而那几套分布 / 线程归属 / 收尾判据在转手形状下
   * 本来就成立 ⇒ 它们同时成了那条腿的证据。
   *
   * 不新增运行路径：它只让 `bind_flags_for_loops()` 返回 0（= 不带那个标志去
   * 绑），于是走的是与 Windows / macOS **同一条**回落路径（`bind_on_loops()`
   * 里 `fanout_ = false` 那一步）。
   *
   * @warning 必须在 `set_loops()` 之前调（同 `set_loop_start_hook()`：
   * `is_fanout()` 是**绑定时**探出来的，绑完再改这个标志不会改变已经绑好的
   * 形状）。装晚了会被忽略并打一条 stderr 诊断。
   *
   * @note 这是**测试用的口子**，不是生产用的性能开关 —— 它把内核分流换成用户态
   * 转手，代价更高（见 `doc/multiloop-design.md` §1）。
   */
  void set_handoff_forced(bool on);

  /**
   * @brief 撤销 `set_loops(n > 1)`：停掉并释放全部工作循环，回到单循环状态。
   *
   * **给属主在启动失败时回滚用。** `set_loops(n)` 一返回，n−1 条工作循环就已经
   * 在跑了；而属主接着多半还要做几件**会失败**的事（`bind()` 是其中最常失败的
   * 那件 —— 端口被占）。这一段窗口里属主必须能把工作循环收掉，否则它手上会剩
   * 一个"循环在转、起不来也停不掉"的对象：
   *
   *   ① 它建在那些循环上的句柄（`uv_async` / `uv_timer`）得有人收 —— 在析构里
   *      `delete` 是往一块已经被释放的循环上写 `uv_close`（UAF）。收的地方是
   *      `set_loop_exit_hook()`：循环停下来的那条线程上、内存还在的时候；
   *   ② 再想 `set_loops(n)` 会因 `workers_` 非空而永远返 `UV_EBUSY`。
   *
   * 与 `stop()` 的分工：`stop()` 是"关服"（不再收新连接，已建立的自生自灭），
   * 本函数撤的是"多循环这件事本身" —— 它直接 join 工作线程，那些线程名下的
   * 连接由各自的退出路径关掉（`on_exit` → `close_clients_of_loop`）。所以它
   * **只属于 `listen()` 之前的那段窗口**，这正是下面那道门挡的东西。
   *
   * @return 0 成功（没有工作循环时是空操作，所以"`set_loops()` 自己失败时已经
   *         收过一次"那条路再调一遍无害）；`UV_EBUSY` **`listen()` 已经成功
   *         过** —— 那时工作循环可能已经持有连接，该走 `stop()` / 析构，而不是
   *         把循环从底下抽掉。这道门是**精确**的（`listen_called_` 只在
   *         `listen()` 成功那一条路上置位），不是拿 `TCP_SERVER_LISTENING`
   *         凑的 —— 那个标志是 `bind()` 成功时置的，在 `listen()` 失败那条
   *         路上它已经是真，用它会**反过来挡住本该放行的回滚**。
   */
  int rollback_loops();

  /**
   * @brief 第 \p loop_index 条循环名下**当前登记着**的连接数。
   *
   * **0 号不是恒 0 的**：`is_fanout()` 为真时 0 号（就是 `get_loop()` 那条）
   * 自己也收属于它的那一份（见 `set_loops()` 那段）。越界返回 0。
   *
   * 它就是"分布看得见"的那个读数，但**分布的形状按平台分叉**：转手那条路上
   * 去向是显式轮转（连接数固定时这个数是确定的、逐格均分）；分流那条路上由
   * 内核哈希定（**只保证逐格之和 == `client_count()`**）。别把两端写进同一套
   * 判据 —— 想知道这次是哪一种就问 `is_fanout()`。
   */
  size_t client_count_at(int loop_index) const;

  /**
   * @brief 第 \p index 条循环的句柄。0 = acceptor 那条（就是 `get_loop()`）；
   *        越界返回 nullptr。
   *
   * 为什么上层要得到它：**工作循环的循环对象只有在这里拿得到**，而 UI/属主要
   * 在上面建只属于那条循环的东西（观察点、定时器）时得先有它。net 自己那一族
   * 钩子（`set_loop_start_hook` / `set_loop_exit_hook`）也够用，但它们是**建循环
   * 时**的一次性回调，而上面这层要的是"任何时候都能问到第 i 条是谁"。
   *
   * @note `n == 1` 时它只答得出 `index == 0`（其余返回 nullptr）—— 那时确实
   *       只有一条循环，与今天逐字相同。
   */
  uvcpp_loop* loop_at(int index) const;

  /**
   * @brief 把 \p fn 投到第 \p loop_index 条循环的线程上跑。
   *
   * 用途：属主要在**别的循环**上动它自己那份按循环切的状态（建/收端点、关属主
   * 句柄），而那些动作只能在循环线程上做。`uvcpp_http_server` 的多循环 QUIC 扇出
   * 与它的析构都是靠这个。
   *
   * @return true = 已受理；false = **没受理**（\p loop_index 不在 1..n−1 里，
   *         或者那条工作循环已经不在受理投递了）。与 `uvcpp_loop_worker::post()`
   *         同一条语义：被拒 = 任务当场析构，所以携带 RAII 资源的任务不需要自己
   *         写失败清理。
   *
   * @warning **0 号不吃投递**：那是调用方自己那条循环（`run()` 就在调用方线程
   *          上），"投过去"与"直接调"没有任何区别，而且这里也没法证明调用方
   *          就在那条线程上。要在 0 号上做事，就地做。
   *
   * @note 投递是**异步**的：返回 true 只表示"受理了"，不表示已经跑完。要等它
   *       跑完得自己拿一个 `std::promise` 之类的东西把结果交回来（照
   *       `start_worker_listeners()` 的写法）。
   */
  bool post_to_loop(int loop_index, std::function<void()> fn);

  // -----------------------------------------------------------------
  // Stop
  // -----------------------------------------------------------------

  /**
   * @brief 停止接受新连接：关闭服务器的监听句柄。
   *
   * **不动已建立的连接** —— 它们照常收发，直到自己走完或对端断开。这一点
   * 和"关服"是两件事，所以要分两步：先 `stop()` 不再收新的，把手上正在处理
   * 的做完（这就是优雅关闭里的"排空"），再 `close_all_clients()` 送走剩下的。
   * 想一步到位就两个都调。
   *
   * 已经停止过（或从没 listen 过）时直接调 `on_stopped` 返回，不会重复关闭。
   *
   * @param on_stopped Optional callback invoked when the server has
   *                   fully stopped.
   */
  void stop(std::function<void()> on_stopped = nullptr);

  /**
   * @brief 关掉当前所有已登记的连接（**不影响监听**）。
   *
   * 每个连接都走 `uvcpp_tcp_client::close()`：关闭完成后摘除 + 释放，和对端
   * 断开走同一个收尾。所以调用之后不需要再管这些客户端。
   *
   * 登记表里如果有**句柄已经关掉、人却还留着**的连接（有人绕过框架直接
   * `get_tcp()->close(...)` 的结果），这里顺手把它们归还掉，不再发起关闭。
   *
   * @return 本次**发起关闭**的连接数。已经死掉被顺手归还的、所有权被
   *         `take_client()` 取走的都不计入。
   *
   * @note `set_loops(n>1)` 时：本循环名下的就地关（计入返回值），**别的循环是
   *       投递过去异步发起的**（不计入返回值）。所以 n>1 时这个数**不表示
   *       "已经关掉多少"** —— 要看关没关干净，看 `client_count()` 回零。
   *
   * @warning 必须在 loop 线程调用（n>1 时是**接受者**那条循环的线程）。
   */
  size_t close_all_clients();

  /**
   * @brief 关掉挂在 \p l 这条循环上的全部已登记连接 —— `close_all_clients()`
   *        的**每循环那一份**，不投递、不跨界。
   *
   * 语义与 `close_all_clients()` 的"本循环那一份"逐字相同（同一次快照、同一
   * 个 `get_loop() != l` 筛选、同一套顺手归还死连接的规则），区别只在于**它
   * 不会去碰别的循环**：不投递任何任务，返回的就是本次真正发起关闭的条数。
   *
   * 存在的理由是**停机次序**：优雅关闭要求"先发 Close/GOAWAY 帧、等它们出网、
   * 再关连接"。`close_all_clients()` 会把这件事劈成 n 份投递（acceptor 就地、
   * worker 各自异步），于是 0 号可以在别的循环还没道完别的时候就把它们的连接
   * 关了 —— 而那些循环上一拍才排队的帧一个字节都发不出去，对端只看到 1006。
   * 按循环各关各的，这条次序就在每一格内部**各自**成立，与 `n == 1` 同形，
   * 不需要任何跨循环栅栏。
   *
   * @return 本次**发起关闭**的条数（顺手归还的死连接不计）。
   *
   * @warning 必须在 \p l 的线程上调用。它不投递、不加锁地碰连接对象，
   *          从别的线程调就是隔着线程去动别人的连接。停机时每一格在**自己**
   *          那条循环上各调一次（这正是它的用法）。
   */
  size_t close_clients_on_loop(uvcpp_loop* l);

  // -----------------------------------------------------------------
  // 读：由框架统一管理
  // -----------------------------------------------------------------

  /**
   * @brief 设置**所有连接**共用的读回调（带语义的框架层读）。
   *
   * 这是给上层框架（webapp）用的入口：注册一次，之后每个被接受的连接都从
   * 这里拿数据。回调签名见 `net_read_result` —— 数据、对端正常关闭、读错误
   * 是三个**明确的事件**，而不是让用户去猜 `uvcpp_buf` 为什么没来。
   *
   * 设了它之后，每个新连接会自动 `read_start_events()`，使用者**不需要**也
   * **不应该**再在 `on_connection` 里自己 `read_start()`（那会拿到
   * `UV_EALREADY`）。设它之前 `on_connection` 里注册的读回调优先级更高。
   *
   * @warning 必须在 loop 线程调用，且应当在 `listen()` 之前设好。
   */
  void set_read_callback(const uvcpp_net_read_cb& cb);

  /** @brief 清掉共用的读回调（回到自动读兜底）。 */
  void clear_read_callback();

  /** @brief 是否设过共用的读回调。 */
  bool has_read_callback() const;

  /**
   * @brief 是否给新连接自动起读（默认 **true**）。
   *
   * 为什么默认开：**断开只在读回调里看得见**（`nread < 0` 分支），不读的连接
   * 永远不会被发现断开，也就永远不会走关闭回调、不会被回收 —— 那是每连接
   * 泄漏一个客户端对象的静默缺陷。默认自动读之后，"忘记起读"这个失败模式
   * 从根上没有了。
   *
   * 关掉它只在一种情况下有意义：你要自己完全接管读路径，且**自己负责发现
   * 断开**。
   */
  void set_auto_read(bool enable);
  bool auto_read() const;

  /**
   * @brief 暂停某个连接的读（背压）。
   *
   * 给"消费者跟不上生产者的速度"用：比如上传落盘跟不上、或者有界队列满了。
   * 连接上已注册的读回调**不会**被清掉，`resume_read()` 之后继续往同一个
   * 回调投递。被暂停期间数据留在内核缓冲区里，对端会因为 TCP 窗口而自然
   * 减速。
   *
   * @return 0 成功；非 0 为 libuv 错误码。客户端不归本服务端管时返回
   *         `UV_EINVAL`（不能对别人的连接动手）。
   *
   * @note `set_loops(n>1)` 时这条连接只可能在**它自己那条循环的线程**上被
   *       暂停/恢复 —— 从别的线程调是未定义行为（`owns_client` 那一问是加锁
   *       的、跨线程安全，但真正动句柄那一步不是）。
   */
  int pause_read(uvcpp_tcp_client* client);

  /** @brief 恢复某个连接的读。语义见 `pause_read()`。 */
  int resume_read(uvcpp_tcp_client* client);

  // -----------------------------------------------------------------
  // 客户端所有权：三态
  // -----------------------------------------------------------------

  /**
   * @brief 本服务端当前登记的客户端数量（**所有循环的合计**）。
   *
   * 取走所有权（`take_client`）的客户端**不计入**这里 —— 它们已经不归
   * 服务端管了。可以用它来断言"没有泄漏"：连接关掉一批之后这个数应该
   * 回到基线。
   *
   * 登记表是加锁的，所以**从任何线程调都对**。n>1 时它是一份快照：读数的那一
   * 刻别的线程可能正在增删，所以"回到 0"这件事要**重试着看**，不要只看一次。
   */
  size_t client_count() const;

  /** @brief 这个客户端当前是否归本服务端管理。可跨线程调用（登记表加锁）。 */
  bool owns_client(const uvcpp_tcp_client* client) const;

  /**
   * @brief **取走所有权**：把客户端从服务端手里摘出来，交给你自己管。
   *
   * 调用之后服务端**再也不碰它**：不关闭、不释放、不做任何后续处理，
   * 也不再从它那里收到任何回调。你必须自己负责在合适的时候
   * `client->get_tcp()->close(...)` 并 `delete client`。
   *
   * 什么时候需要它：
   *   - 要把连接**长期留住**当成一条自己的信道（比如协议升级后自己接管
   *     读写、或者把连接转交给另一个对象/线程）；
   *   - 要用一个不是 `delete` 的方式来回收（放进自己的对象池）。
   *
   * **不取走就什么都不用做**：默认情况下客户端完全由服务端管理，断开时
   * 自动摘除并释放，使用者不需要写任何清理代码。
   *
   * @return 成功返回同一个指针；如果它本来就不归本服务端管（已经取走过、
   *         已经交还过、或者压根不是这里的客户端）返回 nullptr。
   *         返回 nullptr 时**所有权没有变化**，不要据此去 delete。
   *
   * @note 取走的是**管理权**，不是"这条连接从今往后归你随便驱动"。`set_loops(n>1)`
   *       时它的事件仍然只在**它自己那条循环的线程**上到达，你也只能在那个线程上
   *       驱动它（在自己的回调里，或者把活儿投到那条循环的邮箱上）。在别的线程上
   *       对它 `write`/`close` 是未定义行为。
   *
   * @warning 必须在 loop 线程上调用。
   */
  uvcpp_tcp_client* take_client(uvcpp_tcp_client* client);

  /**
   * @brief **交还所有权**：把之前 `take_client()` 取走的客户端还给服务端。
   *
   * 交还之后它重新受服务端管理 —— 断开时自动摘除并释放，你就不必再管了。
   *
   * 连接**已经关闭**的情况下不会重新登记（它不可能再产生事件了），而是
   * 就地释放并返回 true。这就是"由框架决定是删除还是复用"的落点：现在是
   * 删除；将来要加客户端对象池，复用的分支就接在这里。
   *
   * @return 交还成功返回 true。客户端本来就归服务端管（重复交还）返回
   *         false，此时什么都没发生。
   *
   * @note `set_loops(n>1)` 时它回到**它自己那条循环**名下（登记表里记的是
   *       客户端自己的 `get_loop()`，不是"你现在所在的这条"），所以交还必须
   *       在它自己那条循环的线程上做。
   *
   * @warning 必须在 loop 线程上调用。交还之后**不要**再持有那个指针。
   */
  bool return_client(uvcpp_tcp_client* client);

  // -----------------------------------------------------------------
  // TLS（HTTPS / WSS 服务端）
  // -----------------------------------------------------------------

#if UVCPP_OPENSSL_ENABLE
  /**
   * @brief 给之后接受的每条连接装上 TLS 过滤层。
   *
   * 装上之后，**上层的 `on_connection` 被推迟到握手成功之后**才调用：握手
   * 没完成时连接算不上可用（此时 `write()` 必然失败，因为 SSL_write 要求
   * 握手已完成），所以不把它交出去。客户端一上来就打明文（比如直接把
   * HTTP 请求写进 TLS 端口）时，握手失败 —— 上层收到的是**根本没被通知
   * 过这条连接**，连接由框架自行收尾，不会走 `on_connection`。
   *
   * 握手失败只记账（`last_error_code_`），不额外做清理：收尾走的是和明文
   * 读错误完全相同的一条路（读侧通知 → close manager 摘除并释放）。
   *
   * @param ctx 生命周期必须覆盖整个服务端（本服务端**不持有**它的所有权，
   *            也不负责释放）。用 `uvcpp_ssl_context` 的 SERVER 模式，
   *            并装好证书/私钥。
   *
   * @warning 必须在 `listen()` 之前设置。清空用 `set_ssl_context(nullptr)`。
   * @warning 必须在 loop 线程调用。
   */
  void set_ssl_context(uvcpp_ssl_context* ctx);

  /** @brief 当前的 TLS 上下文；没装 TLS 时为 nullptr。 */
  uvcpp_ssl_context* ssl_context() const { return ssl_ctx_; }

  /**
   * @brief TLS 握手的超时（毫秒）。0 = 不设。默认 10000。装 TLS 才有意义。
   *
   * 服务端在握手成功之前**不会**把连接交给上层（见 `uvcpp_tcp_client::
   * set_tls_ready_callback`），所以这期间这条连接不在上层的连接表里，上层的
   * 闲置超时看不到它。没有这道闸门时，一个「连上之后每 500 ms 发一个字节喂
   * ClientHello、永远不把握手做完」的客户端可以让连接无限期挂着。
   *
   * 值会传给之后 accept 的每一条连接；已经建立的连接不受影响。
   * @warning 必须在 loop 线程调用。
   */
  void set_tls_handshake_timeout_ms(int ms);

  /** @brief 当前的 TLS 握手超时；0 表示不设。 */
  int tls_handshake_timeout_ms() const { return tls_hs_timeout_ms_; }
#endif  // UVCPP_OPENSSL_ENABLE

  // -----------------------------------------------------------------
  // Loop control
  // -----------------------------------------------------------------

  /** @brief Run the internal event loop. */
  int run(uv_run_mode md = UV_RUN_DEFAULT);

  /** @brief Stop the internal event loop. */
  void stop_loop();

 private:
  // -----------------------------------------------------------------
  // Internal helpers
  // -----------------------------------------------------------------

  void set_status(int flags);
  void clear_status(int flags);

  /**
   * @brief 摘除 + 释放一个客户端（关闭收尾的唯一落点）。
   *
   * 用户的 `on_close` 观察槽和框架的管理槽都走到这里；`close_all_clients()`
   * 清理"句柄已关、人还在"的残留也用它。
   *
   * @warning 调用之后不能再持有 `client`。
   */
  void release_client(uvcpp_tcp_client* client);

  /** @brief Post-connection callback: check/set client callbacks. */
  void setup_client_callbacks(uvcpp_tcp_client* client);

  /**
   * @brief 给客户端装上框架的关闭管理回调（摘除 + 释放）。
   *
   * 走的是 `set_close_manager()` 而不是用户的 `set_on_close()` —— 两个槽
   * 分开，用户的回调就永远无法取消框架的释放。
   */
  void install_client_manager(uvcpp_tcp_client* client);

  /**
   * @brief 用户 on_connection 回调抛异常时的收尾：关掉并回收这个客户端。
   *
   * 不直接 `delete`：那时连接句柄还是活的，在 libuv 的 accept 回调里同步
   * 析构一个活动句柄不安全。改成走关闭流程，在它的完成回调里摘除 + 释放。
   */
  void close_client_on_callback_error(uvcpp_tcp_client* client);

  /**
   * @brief 把连接交给上层（`on_connection`），带异常兜底。
   *
   * 抽出来是因为它有**两个**调用点：不装 TLS 时在 accept 回调里直接就调；
   * 装了 TLS 时推迟到握手完成的通知里。两处必须走同一段逻辑。
   *
   * **刻意不在 `#if UVCPP_OPENSSL_ENABLE` 里面。** 不装 TLS 的那条路
   * （`listen()` 的 accept 回调末尾）也调它，而那句调用在 `#endif` 之外 ——
   * 把声明一起关掉会让**没开 OpenSSL 的构建直接编译不过**。这个错误曾经
   * 真的存在过：`build-ssl` 单独加了这个函数、`build-webapp` 没跟着重建，
   * 于是那边编译失败而 ctest **照样报 54/54 全绿**（跑的是上一轮的陈旧
   * 二进制）。比红更坏的是"因为没构建而看起来是绿"。
   */
  void deliver_connection(uvcpp_tcp_client* client);

#if UVCPP_OPENSSL_ENABLE
  /**
   * @brief 握手结束（成功/失败）时的服务端侧处理。
   *
   * 成功 → `deliver_connection()`；失败 → 只记 `last_error_code_`，收尾
   * 交给框架既有的那条路（见头文件里 `set_ssl_context` 的说明）。
   */
  void on_tls_handshake_done(uvcpp_tcp_client* client, int status);

  /** @brief 服务端级 TLS 上下文（非拥有）。nullptr = 明文。 */
  uvcpp_ssl_context* ssl_ctx_ = nullptr;
  /** TLS 握手超时（毫秒）；0 = 不设。accept 时传给每条新连接。 */
  int tls_hs_timeout_ms_ = 10000;
#endif  // UVCPP_OPENSSL_ENABLE

  // -----------------------------------------------------------------
  // 多循环（`set_loops(n > 1)` 时才用得上）
  // -----------------------------------------------------------------

  /**
   * @brief acceptor 侧：把刚接受的连接取出来转手给某个 worker。
   *
   * 只在 `workers_` 非空时被调。**必须在关掉 acceptor 侧那个临时句柄之前**
   * 把 socket 取出来（`uv_close` 会同步关掉它那份 fd），所以顺序是
   * 取 fd → 转手 → 关临时句柄。
   *
   * 任何一步失败都只记账（`last_error_code_` / `TCP_SERVER_ERROR`）并放掉
   * 已经造出来的东西 —— **不**让一条坏连接把整个 accept 回调掀掉。
   */
  void accept_and_handoff(uvcpp_stream* s);

  /**
   * @brief 这次绑定要不要带 `UV_TCP_REUSEPORT`（= 要不要走内核分流）。
   *
   * `n == 1`（含从没调过 `set_loops()`）一律返回 0：与今天逐字节相同，也没有
   * 平台差异。`n > 1` 时 Windows 上返回 0（libuv 那边看到这个标志是无条件
   * 拒绝，试都不用试），其余平台先返回标志 —— **真伪由 `bind_on_loops()` 里
   * 那次绑定的返回码定**，见那条注释。
   */
  int bind_flags_for_loops() const;

  /**
   * @brief `bindIpv4()`/`bindIpv6()` 的公共正文：绑一次，必要时回落到转手。
   *
   * 地址要留下来（分流时每条工作循环都得拿同一个地址各绑一个句柄）。
   */
  int bind_on_loops(const char* ip, int port, bool ipv6);

  /**
   * @brief 给每条工作循环各建一个监听句柄，等它们全绑上才返回。
   *
   * 只在分流（`fanout_`）且 `0` 号那次 `listen()` 成功之后调，跑在
   * **acceptor 的线程**上；句柄本身在各自的工作循环线程上建。
   * 任一条起不来就把已经起来的收回去并返回第一个错（整体失败）。
   */
  int start_worker_listeners(int backlog);

  /**
   * @brief 关掉第 \p worker_index 条工作循环的监听句柄。
   *
   * **必须在它自己的那条循环线程上跑** —— 两个调用点都在 worker 线程上：
   * 退出钩子、以及失败回滚时的投递。幂等。
   */
  void close_worker_listener(size_t worker_index);

  /**
   * @brief 在 \p l 这条循环上收下 \p s 递来的连接，并跑完整条接受尾巴。
   *
   * `n == 1` 时是 accept 回调里那段（`l` == `loop_`、\p loop_index == 0）；
   * 多循环下"每条循环自收"走同一个形状，只有循环号不同。抽出来是为了让两条路
   * **只差一个循环号**（`finish_accept()` 当初就是按同一条理由抽的）。
   *
   * **必须在 \p l 的线程上跑**（`uv_accept` 与 `enable_tls` 都要求）。
   * \p loop_index 在交付之前写进客户端 —— 上层按它索引每循环表。
   */
  void accept_on_loop(uvcpp_loop* l, int loop_index, uvcpp_stream* s);

  /**
   * @brief worker 线程侧：认领转手过来的 socket，跑完整条接受尾巴。
   *
   * \p sock 一进来就归本函数；无论走哪条失败路径，它都会被恰好关一次。
   */
  void on_handoff_task(int worker_index, uv_os_sock_t sock);

  /**
   * @brief 接受尾巴：登记 → 装读 → TLS → 交付。
   *
   * **必须在目标循环的线程上跑**（`enable_tls` 会当场在这条循环上 arm 一次
   * 读）。`n == 1` 时就是 accept 回调里那段；`n > 1` 时由 worker 线程调 ——
   * 两条路共用这一份，免得以后改一处忘一处。
   */
  void finish_accept(uvcpp_tcp_client* client);

  /** @brief 登记（加锁）。任何线程可调。 */
  void register_client(uvcpp_tcp_client* client);
  /** @brief 摘除（加锁）。任何线程可调；**不**释放对象。 */
  void unregister_client(uvcpp_tcp_client* client);
  /** @brief 取登记表快照（加锁）。在锁外逐个动手，别跨用户代码持锁。 */
  std::vector<uvcpp_tcp_client*> snapshot_clients() const;

  /**
   * @brief 关掉挂在 \p l 这条循环上的全部登记连接。**在 \p l 的线程上跑。**
   *
   * `close_all_clients()` 的每循环那一份：`n > 1` 时 acceptor 自己那份直接调，
   * 其余各 worker 那份由 `post()` 投进去。worker 退出前的收尾也用它。
   *
   * @return 本次**发起关闭**的条数（顺手归还的死连接不计）。
   */
  size_t close_clients_of_loop(uvcpp_loop* l);

  /** @brief 停掉并 join 全部 worker（幂等）。**必须在既有四步收尾之前**调。 */
  void stop_workers();

  // 私有 + `friend uvcpp_http_server`，与 `uvcpp_web_stream` 那边同一条理由：
  // 上层析构**必须**在动它自己那几张按循环切的表之前把工作循环停掉 —— worker
  // 的退出路径会关上自己名下的连接，而那条路会经由关闭回调跑 `remove_ctx`，
  // 写的正是那几张表。公开 `stop_workers()` 等于允许任意调用方在循环还转着的
  // 时候把工作线程拆掉。
  friend class uvcpp_http_server;

  // Trampoline — C-style fn ptr + void* to avoid MSVC std::function
  // copy-chain corruption through libuv's callback layers.
  using connection_callback_t = void(*)(uvcpp_tcp_client* client,
                                        void* arg);

  // -----------------------------------------------------------------
  // Member variables
  // -----------------------------------------------------------------

  uvcpp_loop* loop_ = nullptr;
  uvcpp_tcp*  tcp_  = nullptr;
  /**
   * @brief 本对象是否拥有 `loop_`（外部循环构造时为 false）。
   *
   * 析构的第三步（泵循环、`loop_close()`、`delete loop_`）只在这一位为真时
   * 跑。外部循环那条路上**整段跳过**：循环不是我们的，关它等于把同一条循环
   * 上别的对象的句柄连同它们的事件一起废掉，`delete` 更是直接还别人的内存。
   */
  bool owns_loop_ = true;
  bool stopped_     = false;  ///< true if stop() already closed the handle

  /**
   * @brief `listen()` **成功**过没有 —— `rollback_loops()` 那道门的判据。
   *
   * 与 `TCP_SERVER_LISTENING` 不是一回事：那个标志在 `bind()` 成功时就置了，
   * 而 `bind()` 与 `listen()` 之间正是 `rollback_loops()` 唯一该被放行的窗口。
   * 拿状态位去挡会把它反着挡掉（见 `rollback_loops()` 的注释）。
   */
  bool listen_called_ = false;

  /**
   * @brief 状态位。
   *
   * `n > 1` 时 **worker 线程上也会写**（转手失败要记账），而用户随时可能从
   * 别的线程 `get_status()` —— 所以是原子。读-改-写在 `set_status` 里用
   * `fetch_or`/`fetch_and`，不是"读出来再写回去"。
   */
  std::atomic<int> status_{TCP_SERVER_NONE};
  /** @brief 最近一次错误码。同上：worker 线程可能写。 */
  std::atomic<int> last_error_code_{0};

  /**
   * @brief 全服务端的连接登记表 + 它的锁。
   *
   * **一张表，不是每循环一张。** `n > 1` 时这张表被多个线程碰：worker 线程
   * 在收尾时摘除、用户可能从任何线程 `client_count()` / `owns_client()`。
   * 锁只护"读表 / 改表"这一步 —— 绝不跨 `client->close()`、也绝不跨用户代码
   * 持有（用户回调里再进 `client_count()` 就是死锁）。
   *
   * `n == 1` 时它仍然只有 acceptor 线程碰，锁是白拿的（`std::mutex` 未竞争
   * 时就是一条原子指令）。
   */
  std::vector<uvcpp_tcp_client*> clients_;
  mutable std::mutex clients_mu_;

  /** @brief 工作循环（n−1 条；`n == 1` 时为空 = 今天那条路）。 */
  std::vector<uvcpp_loop_worker*> workers_;
  /** @brief 轮转计数：第 i 条连接给 `1 + (i % (n-1))`。 */
  std::atomic<uint64_t> rr_{0};

  /**
   * @brief 分流用：绑定时记下的地址，以及"这次绑定到底分流成没成"。
   *
   * `fanout_` 只在 `bindIpv4()`/`bindIpv6()` 里写一次（那时工作线程还没起），
   * 之后只读 —— 读它的人包括 accept 回调（acceptor 线程）。
   */
  std::string bind_ip_;
  int bind_port_ = 0;
  bool bind_is_ipv6_ = false;
  bool fanout_ = false;
  /**
   * @brief `set_handoff_forced(true)` 记下来的请求。
   *
   * 与 `fanout_` 并列（两个 `bool` 之后就是 8 字节对齐的 `worker_listeners_`）
   * ⇒ 它落进既有 padding，**`sizeof` 不变**（实测：改动前后都是 336）。
   * 与 `fanout_` 一样：在 `set_loops()` 之前写、之后只读。
   */
  bool handoff_forced_ = false;

  /**
   * @brief 每条工作循环自己的那个监听句柄（只有 `fanout_` 时非空）。
   *
   * **`resize` 必须在投递之前做**：尺寸定死之后第 i 格只由 i 号工作循环的
   * 线程写（建也是它、关也是它），谁都不与谁并发，所以不需要锁 —— 投递那
   * 一下的交手本身就是先后关系。`n == 1` 时它恒为空。
   */
  std::vector<std::shared_ptr<uvcpp_tcp> > worker_listeners_;

  /**
   * @brief `set_loop_start_hook()` 装进来的钩子。
   *
   * **必须在 `set_loops()` 之前写、之后只读** —— 它在 worker 线程上被读，写它
   * 的人和读它的人之间靠 `start()` 的交握手建立先后关系（与 `ssl_ctx_` 同一套）。
   * 装晚了不会报错也不会生效，见那条 `@warning`。
   */
  std::function<void(int, uvcpp_loop*)> loop_start_hook_;

  /**
   * @brief `set_loop_exit_hook()` 装进来的钩子。
   *
   * **必须在 `set_loops()` 之前写、之后只读**（同 `loop_start_hook_`）。读它的
   * 那条线程就是 `start()` 起的那一条，先后关系由那次调用里的交握手建立；
   * 与就绪钩子的差别只是读的时机 —— 它在**线程退出路径**上，不在开跑时。
   */
  std::function<void(int, uvcpp_loop*)> loop_exit_hook_;

  /** @brief User connection callback stored as trampoline pair. */
  connection_callback_t on_connection_fn_ = nullptr;
  void*                 on_connection_arg_ = nullptr;

  /** @brief 所有连接共用的读回调（set_read_callback）。空则走自动读。 */
  uvcpp_net_read_cb read_cb_;
  /** @brief 自动给新连接起读（默认 true，见 set_auto_read）。 */
  bool auto_read_ = true;

  /**
   * @brief `set_tcp_nodelay()` 设的值（默认 true）。
   *
   * **必须在 `listen()` / `set_loops()` 之前写、之后只读**：它在每次 accept
   * 时被读，多循环下读它的就是那些 worker 线程（同 `loop_start_hook_`）。
   */
  bool tcp_nodelay_ = true;
};

}  // namespace uvcpp

#endif  // SRC_NET_UVCPP_TCP_SERVER_H
