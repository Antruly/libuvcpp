/**
 * @file uvcpp_config.h
 * @brief Module enable macros of THIS build. Generated at configure time.
 *
 * DO NOT EDIT, and DO NOT define these macros yourself. Rebuild uvcpp instead.
 *
 * Several public headers guard *member layout* with these macros -- e.g.
 * `uvcpp_web_app` declares `ssl_ctx_` under `#if UVCPP_OPENSSL_ENABLE`, and that
 * member sits BEFORE `http_` / `registry_`. An undefined macro makes `#if`
 * evaluate to 0, so a consumer TU lays the class out differently than the DLL
 * did; an inline accessor then reads at the wrong offset and returns garbage
 * with no compile error, no link error and no runtime warning.
 *
 * Rule enforced below:
 *   externally defined AND different  ->  #error (hard compile failure)
 *   not defined                       ->  take this build's value
 *
 * The second half is what makes a consumer that defines nothing correct. The
 * first half is what turns a silent bad value into a build break.
 *
 * This file is deliberately ASCII-only: it is compiled by consumers whose
 * toolchain and locale we do not control.
 */

#ifndef UVCPP_GENERATED_CONFIG_H
#define UVCPP_GENERATED_CONFIG_H

#if defined(UVCPP_NET_ENABLE) && (UVCPP_NET_ENABLE != 1)
#  error "UVCPP_NET_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_NET_ENABLE
#  define UVCPP_NET_ENABLE 1
#endif

#if defined(UVCPP_WEB_ENABLE) && (UVCPP_WEB_ENABLE != 1)
#  error "UVCPP_WEB_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_WEB_ENABLE
#  define UVCPP_WEB_ENABLE 1
#endif

#if defined(UVCPP_WEBAPP_ENABLE) && (UVCPP_WEBAPP_ENABLE != 1)
#  error "UVCPP_WEBAPP_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_WEBAPP_ENABLE
#  define UVCPP_WEBAPP_ENABLE 1
#endif

#if defined(UVCPP_WSDL_ENABLE) && (UVCPP_WSDL_ENABLE != 1)
#  error "UVCPP_WSDL_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_WSDL_ENABLE
#  define UVCPP_WSDL_ENABLE 1
#endif

#if defined(UVCPP_YYJSON_ENABLE) && (UVCPP_YYJSON_ENABLE != 1)
#  error "UVCPP_YYJSON_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_YYJSON_ENABLE
#  define UVCPP_YYJSON_ENABLE 1
#endif

#if defined(UVCPP_ZLIB_ENABLE) && (UVCPP_ZLIB_ENABLE != 1)
#  error "UVCPP_ZLIB_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_ZLIB_ENABLE
#  define UVCPP_ZLIB_ENABLE 1
#endif

#if defined(UVCPP_BROTLI_ENABLE) && (UVCPP_BROTLI_ENABLE != 1)
#  error "UVCPP_BROTLI_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_BROTLI_ENABLE
#  define UVCPP_BROTLI_ENABLE 1
#endif

/* 1 if this build has an HTTP body compressor at all, i.e. if either encoder is
   in — 它不是开关，是两个编码器开关的**或**（`UVCPP_HTTP_COMPRESS_ENABLE` =
   `(UVCPP_ZLIB_ENABLE || UVCPP_BROTLI_ENABLE)`）。

   `uvcpp_http_server` 那套（协商 → 变体缓存 → 响应头）与 `uvcpp_web_app`
   那一条转发判的都是它。**用它而不是用 `UVCPP_ZLIB_ENABLE`**：这个值由构建
   代进一个**字面量表达式**（`(0||1)` 这种），三处（本头、目录编译定义、目标
   导出集）存的是同一个字符串 —— 各自算一位迟早会漂。 */
#if defined(UVCPP_HTTP_COMPRESS_ENABLE) && (UVCPP_HTTP_COMPRESS_ENABLE != (1||1))
#  error "UVCPP_HTTP_COMPRESS_ENABLE=(1||1) in this build; remove your own definition of it"
#endif
#ifndef UVCPP_HTTP_COMPRESS_ENABLE
#  define UVCPP_HTTP_COMPRESS_ENABLE (1||1)
#endif

#if defined(UVCPP_OPENSSL_ENABLE) && (UVCPP_OPENSSL_ENABLE != 1)
#  error "UVCPP_OPENSSL_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_OPENSSL_ENABLE
#  define UVCPP_OPENSSL_ENABLE 1
#endif

#if defined(UVCPP_NGHTTP2_ENABLE) && (UVCPP_NGHTTP2_ENABLE != 1)
#  error "UVCPP_NGHTTP2_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_NGHTTP2_ENABLE
#  define UVCPP_NGHTTP2_ENABLE 1
#endif

#if defined(UVCPP_QUIC_ENABLE) && (UVCPP_QUIC_ENABLE != 1)
#  error "UVCPP_QUIC_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_QUIC_ENABLE
#  define UVCPP_QUIC_ENABLE 1
#endif

#if defined(UVCPP_HTTP3_ENABLE) && (UVCPP_HTTP3_ENABLE != 1)
#  error "UVCPP_HTTP3_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_HTTP3_ENABLE
#  define UVCPP_HTTP3_ENABLE 1
#endif

#if defined(UVCPP_CAPI_ENABLE) && (UVCPP_CAPI_ENABLE != 1)
#  error "UVCPP_CAPI_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_CAPI_ENABLE
#  define UVCPP_CAPI_ENABLE 1
#endif

#if defined(UVCPP_REDIS_ENABLE) && (UVCPP_REDIS_ENABLE != 1)
#  error "UVCPP_REDIS_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_REDIS_ENABLE
#  define UVCPP_REDIS_ENABLE 1
#endif

#if defined(UVCPP_DB_ENABLE) && (UVCPP_DB_ENABLE != 1)
#  error "UVCPP_DB_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_ENABLE
#  define UVCPP_DB_ENABLE 1
#endif

/* 后端宏：模块关掉时它们是 0（不是"未定义"）。写成"未定义"的话
   `#if UVCPP_DB_SQLITE_ENABLE` 求值也是 0，结果碰巧一样 —— 而碰巧一样的东西
   在 `-Wundef` 下会变成一条警告，且它自己说不清"这个后端是关着还是模块没编"。 */
#if defined(UVCPP_DB_SQLITE_ENABLE) && (UVCPP_DB_SQLITE_ENABLE != 1)
#  error "UVCPP_DB_SQLITE_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_SQLITE_ENABLE
#  define UVCPP_DB_SQLITE_ENABLE 1
#endif

#if defined(UVCPP_DB_MYSQL_ENABLE) && (UVCPP_DB_MYSQL_ENABLE != 1)
#  error "UVCPP_DB_MYSQL_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_MYSQL_ENABLE
#  define UVCPP_DB_MYSQL_ENABLE 1
#endif

#if defined(UVCPP_DB_PGSQL_ENABLE) && (UVCPP_DB_PGSQL_ENABLE != 1)
#  error "UVCPP_DB_PGSQL_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_PGSQL_ENABLE
#  define UVCPP_DB_PGSQL_ENABLE 1
#endif

/* ODBC 后端。注意它与上面三个不是一类：SQLite/MySQL/PostgreSQL 各对着**一种**
   数据库，而这个对着**一个接口** —— 连什么库由连接串里的 `Driver=`（或 `DSN=`）
   决定，本驱动不去试别的驱动名。所以"这个后端在不在"与"要连的那个数据源有没有
   驱动"是两件事：后者要到 `open()` 才知道，报错是驱动管理器给的原文（驱动名写错
   时就是它那句"找不到数据源、也没有默认驱动"）。 */
#if defined(UVCPP_DB_ODBC_ENABLE) && (UVCPP_DB_ODBC_ENABLE != 1)
#  error "UVCPP_DB_ODBC_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_ODBC_ENABLE
#  define UVCPP_DB_ODBC_ENABLE 1
#endif

/* MongoDB 后端。它与上面几个的**失败方式**不同：客户端库本仓不随包分发，
   所以"这份构建有没有编 MongoDB"（编译期，看 mongoc.h 在不在）与"这台机器
   装没装 libmongoc/libbson"（运行期，第一次 open() 才知道）是两件事。前者看
   这个宏，后者看 open() 的返回值（两种都是 NO_DRIVER，last_error() 分开说）。 */
#if defined(UVCPP_DB_MONGODB_ENABLE) && (UVCPP_DB_MONGODB_ENABLE != 1)
#  error "UVCPP_DB_MONGODB_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_MONGODB_ENABLE
#  define UVCPP_DB_MONGODB_ENABLE 1
#endif

/* MySQL / PostgreSQL 两个后端的符号是**链接进来的**还是**运行时取**的。
   它是"这份产物长什么样"，不是"有哪些模块"，但同样必须让使用者看得见：这两条
   路的**失败方式**不一样（链接的那条在加载期就报缺库、进程起不来；运行时加载的
   那条进程照起，真去连时才拿到 NO_DRIVER），而使用者拿到一句错误信息之后要判断的
   正是"这是我没装库还是这份包没编这个后端"。 */
#if defined(UVCPP_DB_RUNTIME_LOAD) && (UVCPP_DB_RUNTIME_LOAD != 1)
#  error "UVCPP_DB_RUNTIME_LOAD=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_DB_RUNTIME_LOAD
#  define UVCPP_DB_RUNTIME_LOAD 1
#endif

#if defined(UVCPP_ENABLE_MEMORY_POOL) && (UVCPP_ENABLE_MEMORY_POOL != 1)
#  error "UVCPP_ENABLE_MEMORY_POOL=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_ENABLE_MEMORY_POOL
#  define UVCPP_ENABLE_MEMORY_POOL 1
#endif

#if defined(UVCPP_TRY_WRITE_ENABLE) && (UVCPP_TRY_WRITE_ENABLE != 1)
#  error "UVCPP_TRY_WRITE_ENABLE=1 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_TRY_WRITE_ENABLE
#  define UVCPP_TRY_WRITE_ENABLE 1
#endif

/* A value macro, not a 0/1 switch -- compared against its own literal. */
#if defined(UVCPP_TRY_WRITE_MIN_BYTES) && (UVCPP_TRY_WRITE_MIN_BYTES != 32768)
#  error "UVCPP_TRY_WRITE_MIN_BYTES=32768 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_TRY_WRITE_MIN_BYTES
#  define UVCPP_TRY_WRITE_MIN_BYTES 32768
#endif

#if defined(UVCPP_UDP_GSO_ENABLE) && (UVCPP_UDP_GSO_ENABLE != 0)
#  error "UVCPP_UDP_GSO_ENABLE=0 in this build; remove your own definition of it"
#endif
#ifndef UVCPP_UDP_GSO_ENABLE
#  define UVCPP_UDP_GSO_ENABLE 0
#endif

#endif /* UVCPP_GENERATED_CONFIG_H */
