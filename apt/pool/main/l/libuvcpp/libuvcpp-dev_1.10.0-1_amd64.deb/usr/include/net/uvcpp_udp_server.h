﻿/**
 * @file src/net/uvcpp_udp_server.h
 * @brief Higher-level UDP server with bind/receive convenience.
 * @author zhuweiye
 * @version 1.0.0
 *
 * Wraps uvcpp_udp to provide simple bind + recv with per-datagram
 * sender address and send-back capability.  Unlike TCP there are no
 * per-client connections — every datagram is independent.
 */

#pragma once
#ifndef SRC_NET_UVCPP_UDP_SERVER_H
#define SRC_NET_UVCPP_UDP_SERVER_H

#include <functional>
#include <memory>
#include <uv.h>
#include <handle/uvcpp_loop.h>
#include <handle/uvcpp_udp.h>
#include <uvcpp/uvcpp_buf.h>

namespace uvcpp {

enum uvcpp_udp_server_status : int {
  UDP_SERVER_NONE      = 0x00,  ///< Initial state
  UDP_SERVER_BOUND     = 0x01,  ///< Bound to address, receiving
  UDP_SERVER_STOPPING  = 0x04,  ///< stop() called
  UDP_SERVER_STOPPED   = 0x08,  ///< Fully stopped
  UDP_SERVER_ERROR     = 0x10   ///< Error (see last_error_code)
};

/**
 * @brief Application-layer UDP server wrapping uvcpp_udp.
 *
 * Binds to a local address and delivers incoming datagrams to a
 * user callback along with the sender's IP and port.  To reply,
 * call send() or send_wait() with the sender's address.
 *
 * Usage:
 * @code
 *   uvcpp_udp_server server;
 *   server.bind("0.0.0.0", 9999);
 *   server.recv_start([](uvcpp_buf* buf, const char* ip, int port) {
 *     // echo back
 *     server.send(ip, port, buf->get_data(), buf->size());
 *   });
 *   server.run(UV_RUN_DEFAULT);
 * @endcode
 */
class UVCPP_API uvcpp_udp_server {
 public:
  UVCPP_DEFINE_FUNC(uvcpp_udp_server)
  UVCPP_DEFINE_COPY_FUNC_DELETE(uvcpp_udp_server)

  /**
   * @brief 用一条**外部**事件循环，与 `uvcpp_tcp_server(uvcpp_loop*)` 同一约定：
   * 本对象**不拥有**它，析构时也不关不删；`run()` 由调用方负责。
   *
   * issue #59：`uvcpp_web_app` / 中继这类"一条循环上既有
   * WS/TCP 又要 UDP 端点"的场景，自带循环的版本会把回调
   * 放到另一条线程上，跨到循环亲和的连接上就不安全。
   *
   * @warning 外部循环必须活得比本对象长。`stop_loop()` 在外部模式下是**空操作**。
   */
  explicit uvcpp_udp_server(uvcpp_loop* loop);

  // -----------------------------------------------------------------
  // Accessors
  // -----------------------------------------------------------------

  uvcpp_udp* get_udp();
  uvcpp_loop* get_loop();
  int get_status() const;
  bool has_status(int flags) const;
  int get_last_error() const;

  // -----------------------------------------------------------------
  // Bind
  // -----------------------------------------------------------------

  int bind(const char* ip, int port);
  int bindIpv4(const char* ip, int port);
  int bindIpv6(const char* ip, int port);

  // -----------------------------------------------------------------
  // Receive
  // -----------------------------------------------------------------

  /**
   * @brief Start receiving datagrams.
   * @param cb  Called for every datagram: (buf, sender_ip, sender_port).
   *            The callback runs on the event-loop thread; keep it fast
   *            or offload heavy work via uvcpp_work.
   */
  int recv_start(std::function<void(uvcpp_buf*, const char*, int)> cb);

  /** @brief Stop receiving. */
  int recv_stop();

  // -----------------------------------------------------------------
  // Send (reply to a specific address)
  // -----------------------------------------------------------------

  int send(const char* ip, int port, const char* data, size_t len,
           std::function<void(int)> cb = nullptr);
  int send_wait(const char* ip, int port, const char* data, size_t len,
                int timeout_ms = 30000);
  int send(const char* ip, int port, const uvcpp_buf& buf,
           std::function<void(int)> cb = nullptr);
  int send(const char* ip, int port, uvcpp_buf* buf,
           std::function<void(int)> cb = nullptr);

  // -----------------------------------------------------------------
  // Stop
  // -----------------------------------------------------------------

  void stop(std::function<void()> on_stopped = nullptr);

  // -----------------------------------------------------------------
  // Loop control
  // -----------------------------------------------------------------

  /** @brief 外部循环模式下不做任何事（那条循环不是本对象的）。 */
  int run(uv_run_mode md = UV_RUN_DEFAULT);
  void stop_loop();

 private:
  void set_status(int flags);
  void clear_status(int flags);

  // -----------------------------------------------------------------
  // 存活令牌（与 `uvcpp_tcp_client` / `uvcpp_udp_client` 同一套，见那里的说明）
  // -----------------------------------------------------------------
  //
  // 接收回调与 `stop()` 的关闭回调原先捕获裸 `this`。析构之后 libuv 仍可能把
  // 已经挂起的回调送进来，那时回调碰 `status_` / `recv_fn_` 就是读已释放内存。
  // 令牌按值捕进这两个回调：对象活着时 `*token == 0`，析构时置 1。
  //
  // **发送路径不需要**：那几个回调捕获的是用户回调（`user_cb`）或调用方的栈
  // 变量，一个字节的 `this` 都不碰。

  /** @brief 取存活令牌，必要时建立（每个服务端只建一次）。 */
  ::std::shared_ptr<char> alive_token();

  /** @brief 令牌是否表示「对象还活着」。空令牌视为不活着。 */
  static bool token_alive(const ::std::shared_ptr<char>& token);

  using recv_callback_t = void(*)(uvcpp_buf* buf, const char* ip,
                                  int port, void* arg);

  uvcpp_loop* loop_ = nullptr;
  uvcpp_udp*  udp_  = nullptr;
  /// 外部循环构造进来时置 false：析构不关、不删它。
  bool owns_loop_ = true;
  int status_       = UDP_SERVER_NONE;
  int last_error_code_ = 0;

  recv_callback_t recv_fn_  = nullptr;
  void*           recv_arg_ = nullptr;

  ::std::shared_ptr<char> alive_token_;
};

}  // namespace uvcpp

#endif  // SRC_NET_UVCPP_UDP_SERVER_H
