#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "uvcpp::uvcpp" for configuration "Release"
set_property(TARGET uvcpp::uvcpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uvcpp::uvcpp PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuvcpp.so.1.8.9"
  IMPORTED_SONAME_RELEASE "libuvcpp.so.1"
  )

list(APPEND _cmake_import_check_targets uvcpp::uvcpp )
list(APPEND _cmake_import_check_files_for_uvcpp::uvcpp "${_IMPORT_PREFIX}/lib/libuvcpp.so.1.8.9" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
