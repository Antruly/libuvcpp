﻿/**
 * @file src/ssl/uvcpp_ssl_context.h
 * @brief SSL/TLS context — wraps OpenSSL SSL_CTX.
 * @author zhuweiye
 * @version 1.0.0
 *
 * Manages SSL_CTX lifecycle, certificate/key loading, protocol
 * configuration, and verification settings.  One context can be shared
 * across multiple connections.
 */

#pragma once
#ifndef SRC_SSL_UVCPP_SSL_CONTEXT_H
#define SRC_SSL_UVCPP_SSL_CONTEXT_H

#include <uvcpp/uvcpp_config.h>

#if UVCPP_OPENSSL_ENABLE

#include <functional>
#include <map>
#include <string>
#include <vector>
#include <uvcpp/uvcpp_define.h>
#include <ssl/uvcpp_ssl_common.h>

// Forward declarations for OpenSSL types (defined in .cpp via <openssl/ssl.h>)
struct ssl_ctx_st;
struct ssl_st;  // 一条连接的 `SSL`；见 apply_alpn_to_ssl()

namespace uvcpp {

class UVCPP_API uvcpp_ssl_context {
 public:
  UVCPP_DEFINE_FUNC(uvcpp_ssl_context)
  UVCPP_DEFINE_COPY_FUNC_DELETE(uvcpp_ssl_context)

  explicit uvcpp_ssl_context(tls_mode mode,
                              tls_version ver = tls_version::TLS_1_2);

  // -------------------------------------------------------------------
  // Certificate configuration
  // -------------------------------------------------------------------

  /**
   * @brief Load certificate chain from PEM file.
   *
   * **调用顺序：先装证书，再装私钥。** 两个 `load_private_key_*` 内部都会调
   * `SSL_CTX_check_private_key`，而 OpenSSL 在「尚无证书」时该调用返回 0 ——
   * 于是先装私钥**会返回 `false`，但私钥其实已经装进上下文了**：报的是配对检查
   * 失败，状态却已经改了。补装证书之后不用重装私钥。
   */
  bool load_certificate_file(const std::string& path);

  /** @brief Load private key from PEM file. **先装证书再调它**，见上。 */
  bool load_private_key_file(const std::string& path);

  /** @brief Load certificate chain from PEM string. */
  bool load_certificate_data(const std::string& pem);

  /** @brief Load private key from PEM string. **先装证书再调它**，见上。 */
  bool load_private_key_data(const std::string& pem);

  /**
   * @brief 把当前证书（叶子）导出成 PEM。**测试与"证书固定"那类场景用**。
   *
   * `generate_self_signed()` 生成的证书此前没有出口 —— 想把它交给
   * `add_sni_certificate_data()` 或别处，只能落盘再读，而临时文件和文件权限
   * 本身又是一堆平台问题。私钥同理（`private_key_pem()`）。
   *
   * @return true = 导出成功；false = 没有证书 / 内存不足。
   */
  bool certificate_pem(std::string& out) const;

  /** @brief 把当前私钥导出成**未加密**的 PEM（同一条理由，见上）。 */
  bool private_key_pem(std::string& out) const;

  /**
   * @brief Generate a self-signed certificate (for testing).
   * @param common_name  CN field (e.g. "localhost").
   * @param bits         RSA key size (default 2048).
   */
  bool generate_self_signed(const std::string& common_name, int bits = 2048);

  /**
   * @brief 检查已装入的私钥与证书是否配对（`SSL_CTX_check_private_key`）。
   *
   * 为什么值得有一个单独的方法：证书和私钥**不配对**（部署时把两套环境的
   * 文件配到一起，是很常见的手误）在 OpenSSL 里不影响 `SSL_CTX_new`、
   * 也不影响两个 `load_*` 的返回值 —— 它只在**每一次握手**时才失败。于是
   * 表现是"服务起来了、端口在听、每条连接建完就被拒"，很难往配置上想。
   * 在配置阶段调一次就能把它变成一个明确的启动错误。
   *
   * @return 配对返回 true；没装证书/私钥，或两者不配对，返回 false。
   */
  bool check_private_key();

  // -------------------------------------------------------------------
  // CA / verification
  // -------------------------------------------------------------------

  /** @brief Load trusted CA certificates from PEM file. */
  bool load_ca_file(const std::string& path);

  /**
   * @brief 从 **PEM 字符串**装入信任 CA（追加到同一个信任库），#61。
   *
   * 与 `load_ca_file()` 语义相同，只是来源是内存。两张用途：
   *
   *   - **证书固定**：对端把自己的证书经 JSON / 带内消息下发，消费方把它当 CA
   *     用 —— 不需要为此写临时文件、管权限与清理（Windows 上还要处理文件占用）；
   *   - 证书是公开材料，本来没有落盘的必要。
   *
   * 一张 PEM 里可以有多张证书，**逐张追加**；同一张证书装两次是**幂等成功**
   * （与 `load_ca_file()` 对重复项的去重行为一致），不是错误。
   *
   * @return true = 至少读入并装上了一张证书；false = PEM 为空 / 一张都读不出 /
   *         信任库写入失败（后两种会把 OpenSSL 错误栈清掉，与其它 `load_*` 一致）。
   */
  bool load_ca_data(const std::string& pem);

  /**
   * @brief Set peer certificate verification mode.
   *
   * 默认值：CLIENT 上下文是 `PEER`（并已装入系统信任库），SERVER 是 `NONE`。
   * 回环自签用例要在 CLIENT 上显式设 `NONE` —— 关掉校验必须是一个看得见的
   * 动作。
   */
  void set_verify_mode(tls_verify_mode mode);

  /**
   * @brief 当前的对端证书校验档位。
   *
   * 存在的理由：`PEER_STRICT` 那**多出来的一半**（主机名校验）不落在 `SSL_CTX` 上，
   * 而是每条连接各自钉在它的 `SSL*` 上，所以"要不要钉"得由**建连接的那一层**去问
   * 上下文当前的档位。构造期的默认值也走这条路（CLIENT = `PEER`，SERVER = `NONE`，
   * 与 `set_default_verify()` 一致）。
   */
  tls_verify_mode verify_mode() const { return verify_mode_; }

  // -------------------------------------------------------------------
  // Protocol
  // -------------------------------------------------------------------

  /** @brief Set allowed TLS protocol version range. */
  void set_min_version(tls_version ver);
  void set_max_version(tls_version ver);

  /** @brief Set cipher list (OpenSSL format, e.g. "HIGH:!aNULL"). */
  bool set_cipher_list(const std::string& ciphers);

  // -------------------------------------------------------------------
  // ALPN
  // -------------------------------------------------------------------
  //
  // 两个方向分开，因为 OpenSSL 的接口本来就不一样：客户端是"宣告我支持什么"，
  // 服务端是"从对方给的里面挑一个"。顺序都即优先级。

  /**
   * @brief 客户端：宣告本端支持的协议名，例如 {"h2", "http/1.1"}。
   * @return 列表为空（编码后为空）返回 false；否则 true。
   *
   * **写的是共享的 `SSL_CTX`**，所以多个线程共用一个上下文时它必须被同步
   * （本函数内部已经用一把进程内的锁护住"free 旧名单 + malloc 新名单"那一对，
   * 不会再双重释放）。**每条连接各自的名单请走 `apply_alpn_to_ssl()`** ——
   * 那才是逐连接的语义，且完全不共享。
   */
  bool set_alpn_protos(const std::vector<std::string>& protos);

  /**
   * @brief 客户端：把名单装到**一条具体的连接**上，不碰共享的 `SSL_CTX`。
   *
   * 这是 QUIC 会话走的那条路，也是"一个 `uvcpp_ssl_context` 被多条连接、
   * 多个线程共用"时唯一安全的装法：`SSL_CTX_set_alpn_protos` 内部会先 free
   * 掉 ctx 上那份旧名单再 malloc 一份新的，两条线程同时进来就会各自读到同一个
   * 指针、各 free 一次（实测表现：三字节区域上的 `attempting double-free`）。
   * 装到 `SSL*` 上则天然每连接私有，不需要任何同步。
   *
   * @param ssl    `SSL_new()` 出来的连接句柄；本函数不改动 `SSL_CTX`。
   * @return 编码后为空（名单为空、或某个名字超过 255 字节）返回 false；否则 true。
   */
  bool apply_alpn_to_ssl(ssl_st* ssl, const std::vector<std::string>& protos);

  /**
   * @brief 服务端：给出可选的协议名并安装选择回调。
   *
   * **挑不中时回调返回 `SSL_TLSEXT_ERR_NOACK`，不是 fatal。** 这正是"不带 ALPN
   * 的 HTTP/1.1 客户端照常握手成功、由上层回落 h1"的实现方式；写成 fatal 会让
   * 所有老客户端连握手都完不成。无扩展、有扩展但无交集都走这条路。
   *
   * **请在开始 accept 之前调**：回调是注册在 `SSL_CTX` 上的（OpenSSL 没有
   * per-`SSL` 的"选择回调"），名单本体就是本对象的一个成员 —— 一边握手一边
   * 改名单，等于让回调读一个正在被覆盖的 `std::string`。同一份名单重复调是
   * 幂等的，直接返回、不碰 OpenSSL。
   */
  void set_alpn_select_protos(const std::vector<std::string>& protos);

  // -------------------------------------------------------------------
  // SNI（服务端虚拟主机 / 多域名证书）
  // -------------------------------------------------------------------

  /**
   * @brief 服务端：按 SNI 主机名选一套证书。**accept 之前调**。
   *
   * 表里的名字大小写不敏感；`*.example.com` 是**一层**标签的通配
   * （`a.example.com` 命中，`a.b.example.com` 不命中）。同一个名字后加的
   * **替换**先加的。
   *
   * 没带 SNI、或名字不在表里 ⇒ **回落到默认证书**（`load_certificate_*` 装的
   * 那一套）—— 这是"虚拟主机之外还有一个默认站点"的正常形状，不是错误。
   *
   * 回调注册在 `SSL_CTX` 上，所以与 `set_alpn_select_protos()` 同一条纪律：
   * **accept 开始之后不要再改这张表**（握手线程会读到正在被修改的 `std::map`）。
   *
   * @return true = 装上了；false = 不是 SERVER 上下文 / PEM 读不出 / 证书与
   *         私钥不配对 / 内存不足。
   */
  bool add_sni_certificate_data(const std::string& host,
                                const std::string& cert_pem,
                                const std::string& key_pem);
  bool add_sni_certificate_file(const std::string& host,
                                const std::string& cert_path,
                                const std::string& key_path);
  /** @brief 已装了几个 SNI 证书（默认那套不算）。 */
  size_t sni_certificate_count() const { return sni_ctxs_.size(); }

  /**
   * @brief 是否已经装过服务端 ALPN 名单。
   *
   * 给上层用的：`uvcpp_web_app` 默认要替用户宣告 h2，但**不能覆盖用户自己
   * 显式设过的名单**（那是他的协议策略，比框架的默认更权威）。没有这个查询口，
   * 框架只能二选一：要么无条件覆盖，要么一律不设 —— 前者静默改掉用户的配置，
   * 后者让"默认支持 h2"落空。
   *
   * **定义在 .cpp 里**（不是内联）：它读的 `alpn_select_wire_` 是个 `std::string`，
   * 而"谁先装"这件事恰恰发生在多条连接并发建起来的时候 —— 写入侧在锁里，
   * 这个读侧也必须在同一把锁里，否则就是边写边读。
   */
  bool has_alpn_select() const;

  // -------------------------------------------------------------------
  // Status
  // -------------------------------------------------------------------

  bool is_ready() const;
  int get_status() const;
  std::string get_last_error() const;

  // -------------------------------------------------------------------
  // Internal access (for uvcpp_ssl)
  // -------------------------------------------------------------------
  ssl_ctx_st* raw_ctx() const { return ctx_; }

  /**
   * @brief 服务端 0-RTT：允许的 early data 上限（#53）。0 = 关（默认）。
   *
   * 只对 QUIC 服务端有意义：打开之后 `uvcpp_quic_server` 才会在 TLS 上启用
   * 0-RTT 并把带 `max_early_data` 的 ticket 发给客户端。
   */
  void set_max_early_data(uint32_t n);
  uint32_t max_early_data() const;
  tls_mode get_mode() const { return mode_; }

 private:
  void init_client();
  void init_server();
  void set_default_verify();
  void clear_error();

  /// SNI 取证书：OpenSSL 的 servername 回调（注册在 `ctx_` 上）。
  static int sni_select_cb(ssl_st* ssl, int* al, void* arg);
  /// 按名字查一张替代 `SSL_CTX`（精确优先，其次一层通配）。
  ssl_ctx_st* find_sni_ctx(const std::string& host) const;

  ssl_ctx_st* ctx_ = nullptr;
  tls_mode    mode_;
  tls_version min_version_;
  // 与 `mode_`（CLIENT/SERVER）是两件事，名字相近但别混。`SSL_CTX_set_verify` 只
  // 表达得了一半（`PEER_STRICT` 的主机名那一半在每条连接的 `SSL*` 上），所以这里
  // 记的是**原始档位**，供 `verify_mode()` 查。
  tls_verify_mode verify_mode_ = tls_verify_mode::NONE;
  int status_ = TLS_CTX_NONE;
  std::string last_error_;
  // 选择回调通过 arg 拿到的是这个成员的地址，所以它必须活得和 ctx_ 一样久。
  std::string alpn_select_wire_;

  /// SNI 名字（小写）→ 一套**独立**的服务端上下文。默认证书不在表里。
  std::map<std::string, uvcpp_ssl_context*> sni_ctxs_;
  bool sni_cb_installed_ = false;
};

}  // namespace uvcpp

#endif  // UVCPP_OPENSSL_ENABLE
#endif  // SRC_SSL_UVCPP_SSL_CONTEXT_H
